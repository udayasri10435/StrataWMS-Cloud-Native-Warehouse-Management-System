/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { TabMode, BinLocation, InventoryItem, AutonomousRobot, PickWave } from './types/wms';
import {
  INITIAL_SKUS,
  INITIAL_AMRS,
  INITIAL_PICK_WAVES,
  SAMPLE_ASN_MANIFEST,
  generateInitialBins,
} from './utils/mockWarehouseData';
import { calculateOptimizedPath, calculateLegacySShape } from './utils/pickPathOptimizer';
import { TopNav } from './components/TopNav';
import { WarehouseFloorMap } from './components/WarehouseFloorMap';
import { PickPathOptimizerView } from './components/PickPathOptimizerView';
import { ScannerHub } from './components/ScannerHub';
import { RoboticsFleetView } from './components/RoboticsFleetView';
import { InventoryManager } from './components/InventoryManager';
import { ArchitectureComparisonModal } from './components/ArchitectureComparisonModal';

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabMode>('floor');
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [showArchModal, setShowArchModal] = useState(false);

  // Core Warehouse State
  const [bins, setBins] = useState<BinLocation[]>(() => generateInitialBins());
  const [skus, setSkus] = useState<InventoryItem[]>(INITIAL_SKUS);
  const [robots, setRobots] = useState<AutonomousRobot[]>(INITIAL_AMRS);
  const [waves, setWaves] = useState<PickWave[]>(INITIAL_PICK_WAVES);
  const [activeWaveId, setActiveWaveId] = useState<string>(INITIAL_PICK_WAVES[0].id);

  // Floor Map Interaction State
  const [selectedBin, setSelectedBin] = useState<BinLocation | null>(null);
  const [congestedAisles, setCongestedAisles] = useState<number[]>([]);
  const [showLegacyComparison, setShowLegacyComparison] = useState(true);

  // Active Pick Wave
  const currentWave = useMemo(() => {
    return waves.find((w) => w.id === activeWaveId) || waves[0];
  }, [waves, activeWaveId]);

  // Recalculate Dynamic Paths whenever Wave or Congestion changes
  const activePathAnalysis = useMemo(() => {
    return calculateOptimizedPath(currentWave.items, congestedAisles);
  }, [currentWave, congestedAisles]);

  const legacyPathAnalysis = useMemo(() => {
    return calculateLegacySShape(currentWave.items, congestedAisles);
  }, [currentWave, congestedAisles]);

  // AMR Fleet Autonomous Movement Simulation Interval
  useEffect(() => {
    const interval = setInterval(() => {
      setRobots((prevRobots) =>
        prevRobots.map((robot) => {
          if (robot.status === 'CHARGING') {
            const nextBat = Math.min(100, robot.batteryPercent + 1);
            return {
              ...robot,
              batteryPercent: nextBat,
              status: nextBat >= 99 ? 'IDLE' : 'CHARGING',
            };
          }

          if (robot.status === 'NAVIGATING' && robot.targetX !== undefined && robot.targetY !== undefined) {
            const dx = robot.targetX - robot.x;
            const dy = robot.targetY - robot.y;
            const dist = Math.hypot(dx, dy);

            if (dist < 6) {
              // Reached waypoint!
              return {
                ...robot,
                x: robot.targetX,
                y: robot.targetY,
                velocityMps: 0.0,
                status: 'IDLE',
                currentMission: `Arrived at ${robot.targetWaypoint || 'destination'}`,
              };
            }

            // Step forward towards target waypoint
            const step = Math.min(dist, 10);
            const angle = Math.atan2(dy, dx);
            const nextX = Math.round(robot.x + Math.cos(angle) * step);
            const nextY = Math.round(robot.y + Math.sin(angle) * step);

            return {
              ...robot,
              x: nextX,
              y: nextY,
              velocityMps: 1.2,
              batteryPercent: Math.max(5, robot.batteryPercent - (Math.random() < 0.1 ? 1 : 0)),
            };
          }

          return robot;
        })
      );
    }, 1200);

    return () => clearInterval(interval);
  }, []);

  // Handlers
  const handleToggleCongestion = (aisle: number) => {
    setCongestedAisles((prev) =>
      prev.includes(aisle) ? prev.filter((a) => a !== aisle) : [...prev, aisle]
    );
  };

  const handleDispatchRobot = (
    robotId: string,
    targetX: number,
    targetY: number,
    waypointName: string
  ) => {
    setRobots((prev) =>
      prev.map((r) =>
        r.id === robotId
          ? {
              ...r,
              targetX,
              targetY,
              targetWaypoint: waypointName,
              status: 'NAVIGATING',
              currentMission: `Transit to ${waypointName}`,
              lidarObstacleDetected: false,
            }
          : r
      )
    );
  };

  const handleDispatchRobotToBin = (robotId: string, bin: BinLocation) => {
    handleDispatchRobot(robotId, bin.x, bin.y, `Bin ${bin.id} (Aisle ${bin.aisle})`);
  };

  const handleToggleRobotEStop = (robotId: string) => {
    setRobots((prev) =>
      prev.map((r) => {
        if (r.id === robotId) {
          const isAlert = r.status === 'ALERT';
          return {
            ...r,
            status: isAlert ? 'IDLE' : 'ALERT',
            velocityMps: 0,
            currentMission: isAlert ? 'Emergency Hold Cleared' : 'SAFETY E-STOP ENGAGED',
          };
        }
        return r;
      })
    );
  };

  const handleSendToCharge = (robotId: string) => {
    setRobots((prev) =>
      prev.map((r) =>
        r.id === robotId
          ? {
              ...r,
              targetX: 920,
              targetY: 520,
              targetWaypoint: 'Fast-Charge Induction Bay 01',
              status: 'NAVIGATING',
              currentMission: 'Transit to Inductive Charge Bay',
            }
          : r
      )
    );
  };

  const handleAssignWaveToRobot = (waveId: string, robotId: string) => {
    setWaves((prev) =>
      prev.map((w) =>
        w.id === waveId
          ? {
              ...w,
              assignedAmrId: robotId || undefined,
              assignedPicker: robotId ? `${robotId} Autonomous Run` : 'Manual Human Picker',
            }
          : w
      )
    );

    if (robotId) {
      const firstPick = currentWave.items[0];
      if (firstPick) {
        handleDispatchRobot(robotId, firstPick.x, firstPick.y, `Wave Pick 1 (${firstPick.binId})`);
      }
    }
  };

  const handleReceiveAndPutaway = (skuId: string, quantity: number, targetBinId: string) => {
    // Update SKU stock and bin assignment
    setSkus((prev) =>
      prev.map((s) => {
        if (s.id === skuId) {
          const nextOnHand = s.onHand + quantity;
          return {
            ...s,
            binId: targetBinId,
            onHand: nextOnHand,
            available: nextOnHand - s.allocated,
            lastScannedAt: 'Just now',
          };
        }
        return s;
      })
    );

    // Update bin location with SKU
    setBins((prev) =>
      prev.map((b) => {
        if (b.id === targetBinId) {
          return {
            ...b,
            skuId,
            quantity: (b.quantity || 0) + quantity,
          };
        }
        return b;
      })
    );
  };

  const handleUpdateStock = (skuId: string, delta: number) => {
    setSkus((prev) =>
      prev.map((s) => {
        if (s.id === skuId) {
          const nextOnHand = Math.max(0, s.onHand + delta);
          return {
            ...s,
            onHand: nextOnHand,
            available: Math.max(0, nextOnHand - s.allocated),
            lastScannedAt: 'Just now',
          };
        }
        return s;
      })
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar Navigation */}
      <TopNav
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        audioEnabled={audioEnabled}
        onToggleAudio={() => setAudioEnabled(!audioEnabled)}
        onOpenArchComparison={() => setShowArchModal(true)}
        activeWavesCount={waves.length}
        activeRobotsCount={robots.length}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 p-4 lg:p-6 max-w-7xl w-full mx-auto">
        {currentTab === 'floor' && (
          <WarehouseFloorMap
            bins={bins}
            robots={robots}
            activePathAnalysis={activePathAnalysis}
            legacyPathAnalysis={legacyPathAnalysis}
            showLegacyComparison={showLegacyComparison}
            onToggleLegacyComparison={() => setShowLegacyComparison(!showLegacyComparison)}
            selectedBin={selectedBin}
            onSelectBin={setSelectedBin}
            congestedAisles={congestedAisles}
            onToggleCongestion={handleToggleCongestion}
            onDispatchRobotToBin={handleDispatchRobotToBin}
            skus={skus}
          />
        )}

        {currentTab === 'pickpath' && (
          <PickPathOptimizerView
            waves={waves}
            activeWaveId={activeWaveId}
            onSelectWave={setActiveWaveId}
            activePathAnalysis={activePathAnalysis}
            legacyPathAnalysis={legacyPathAnalysis}
            congestedAisles={congestedAisles}
            onToggleCongestion={handleToggleCongestion}
            audioEnabled={audioEnabled}
            robots={robots}
            onAssignWaveToRobot={handleAssignWaveToRobot}
          />
        )}

        {currentTab === 'scanner' && (
          <ScannerHub
            skus={skus}
            audioEnabled={audioEnabled}
            onUpdateSkuStock={handleUpdateStock}
            asnManifest={SAMPLE_ASN_MANIFEST}
          />
        )}

        {currentTab === 'robotics' && (
          <RoboticsFleetView
            robots={robots}
            waves={waves}
            onDispatchRobot={handleDispatchRobot}
            onToggleRobotEStop={handleToggleRobotEStop}
            onSendToCharge={handleSendToCharge}
            onAssignWaveToRobot={handleAssignWaveToRobot}
          />
        )}

        {currentTab === 'inventory' && (
          <InventoryManager
            skus={skus}
            bins={bins}
            audioEnabled={audioEnabled}
            onReceiveAndPutaway={handleReceiveAndPutaway}
            onUpdateStock={handleUpdateStock}
          />
        )}
      </main>

      {/* Architectural Comparison Modal */}
      <ArchitectureComparisonModal
        isOpen={showArchModal}
        onClose={() => setShowArchModal(false)}
      />
    </div>
  );
}
