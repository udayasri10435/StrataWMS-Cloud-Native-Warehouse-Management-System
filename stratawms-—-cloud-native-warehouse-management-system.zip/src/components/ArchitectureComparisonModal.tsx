import React from 'react';
import { Cpu, Check, X, Shield, Zap, Server, Cloud, ArrowRight } from 'lucide-react';

interface ArchitectureComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureComparisonModal: React.FC<ArchitectureComparisonModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-4xl w-full p-6 space-y-6 shadow-2xl my-8">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-cyan-600/20 text-cyan-400 border border-cyan-500/30">
              <Cpu size={20} />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Architectural Breakdown: Modern Cloud-Native vs Legacy On-Prem WMS
              </h2>
              <p className="text-xs text-slate-400">
                Evaluating the shift from legacy monoliths (SAP EWM, Manhattan legacy, Blue Yonder) to event-driven WMS
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 text-xs font-mono px-2 py-1 rounded bg-slate-800 hover:bg-slate-700"
          >
            ✕ Close
          </button>
        </div>

        {/* Core Architectural Comparison Matrix */}
        <div className="overflow-x-auto rounded border border-slate-800">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 font-mono text-slate-400 border-b border-slate-800">
              <tr>
                <th className="p-3 w-1/4">Operational Capability</th>
                <th className="p-3 w-3/8 text-slate-400">Legacy On-Prem WMS</th>
                <th className="p-3 w-3/8 text-cyan-400 font-semibold bg-cyan-950/20">Strata Cloud-Native WMS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 font-mono">
              <tr className="hover:bg-slate-850">
                <td className="p-3 font-semibold text-slate-200">
                  Pick-Path Routing Engine
                </td>
                <td className="p-3 text-slate-400 font-sans">
                  Static S-Shape or Return heuristic. Zero cross-aisle adaptation; causes high deadheading and turns.
                </td>
                <td className="p-3 text-cyan-300 font-sans bg-cyan-950/10 font-medium">
                  Dynamic 2-Opt Graph TSP solver with real-time aisle congestion avoidance and middle bypass routing.
                </td>
              </tr>

              <tr className="hover:bg-slate-850">
                <td className="p-3 font-semibold text-slate-200">
                  Robotics (AMR/AGV) Integration
                </td>
                <td className="p-3 text-slate-400 font-sans">
                  Requires custom proprietary WES/WCS middleware; siloed fleets cannot share map coordinates.
                </td>
                <td className="p-3 text-cyan-300 font-sans bg-cyan-950/10 font-medium">
                  Open VDA-5050 & ROS 2 event streams. Real-time fleet telemetry, unified map twin, and dynamic mission queues.
                </td>
              </tr>

              <tr className="hover:bg-slate-850">
                <td className="p-3 font-semibold text-slate-200">
                  Barcode & RFID Ingestion
                </td>
                <td className="p-3 text-slate-400 font-sans">
                  Telnet / VT220 terminal emulators (green screens); manual batch synchronization every 15-60 mins.
                </td>
                <td className="p-3 text-cyan-300 font-sans bg-cyan-950/10 font-medium">
                  Sub-50ms reactive edge web streams. Instant GS1 AI parsing, 650 tag/sec bulk portal RFID gates.
                </td>
              </tr>

              <tr className="hover:bg-slate-850">
                <td className="p-3 font-semibold text-slate-200">
                  Putaway & Slotting Logic
                </td>
                <td className="p-3 text-slate-400 font-sans">
                  Static zone rules configured months in advance; requires manual database re-indexing.
                </td>
                <td className="p-3 text-cyan-300 font-sans bg-cyan-950/10 font-medium">
                  Dynamic velocity classification (A/B/C), ergonomic height balancing, and minimum travel calculations.
                </td>
              </tr>

              <tr className="hover:bg-slate-850">
                <td className="p-3 font-semibold text-slate-200">
                  Deployment & Infrastructure
                </td>
                <td className="p-3 text-slate-400 font-sans">
                  Local server racks in facility, expensive DB licenses, 6-month patch windows with downtime.
                </td>
                <td className="p-3 text-cyan-300 font-sans bg-cyan-950/10 font-medium">
                  Continuous zero-downtime cloud edge delivery; runs on rugged tablets, gun scanners, and desktop browsers.
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Quantified Impact Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-slate-950 p-3.5 rounded border border-slate-800">
            <span className="text-xs text-slate-400 block mb-1">Pick Travel Distance</span>
            <div className="text-xl font-bold font-mono text-cyan-400">-38.4%</div>
            <span className="text-xs text-slate-500 font-sans">Reduced deadheading via dynamic cross-cuts</span>
          </div>

          <div className="bg-slate-950 p-3.5 rounded border border-slate-800">
            <span className="text-xs text-slate-400 block mb-1">Dock-to-Stock Cycle Time</span>
            <div className="text-xl font-bold font-mono text-emerald-400">4.2 hrs → 42 min</div>
            <span className="text-xs text-slate-500 font-sans">Instant bulk RFID portal pallet receiving</span>
          </div>

          <div className="bg-slate-950 p-3.5 rounded border border-slate-800">
            <span className="text-xs text-slate-400 block mb-1">Hardware Gateway Cost</span>
            <div className="text-xl font-bold font-mono text-amber-400">-70% TCO</div>
            <span className="text-xs text-slate-500 font-sans">Eliminates terminal server licenses</span>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-xs font-semibold transition-colors"
          >
            Acknowledge & Return to Console
          </button>
        </div>
      </div>
    </div>
  );
};
