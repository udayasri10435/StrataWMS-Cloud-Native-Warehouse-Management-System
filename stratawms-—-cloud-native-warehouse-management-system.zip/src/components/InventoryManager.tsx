import React, { useState } from 'react';
import { InventoryItem, BinLocation, VelocityClass } from '../types/wms';
import { Box, Search, ArrowDownToLine, RefreshCw, Plus, CheckCircle, MapPin, Tag } from 'lucide-react';
import { playScanSuccess } from '../utils/audio';

interface InventoryManagerProps {
  skus: InventoryItem[];
  bins: BinLocation[];
  audioEnabled: boolean;
  onReceiveAndPutaway: (skuId: string, quantity: number, targetBinId: string) => void;
  onUpdateStock: (skuId: string, delta: number) => void;
}

export const InventoryManager: React.FC<InventoryManagerProps> = ({
  skus,
  bins,
  audioEnabled,
  onReceiveAndPutaway,
  onUpdateStock,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [velocityFilter, setVelocityFilter] = useState<'ALL' | VelocityClass>('ALL');
  const [showPutawayModal, setShowPutawayModal] = useState(false);

  // Putaway suggestion workflow state
  const [selectedReceiveSkuId, setSelectedReceiveSkuId] = useState(skus[0]?.id || '');
  const [receiveQuantity, setReceiveQuantity] = useState(25);
  const [suggestedBin, setSuggestedBin] = useState<BinLocation | null>(null);

  const selectedReceiveSku = skus.find((s) => s.id === selectedReceiveSkuId) || skus[0];

  // Calculate algorithmic putaway slot:
  // - High velocity A items -> Aisles 1-3, Levels 1-2 (low travel distance, ergonomic pick height)
  // - Bulky items > 10kg -> Level 1 (bottom rack for stability and heavy AGV lift)
  // - Low velocity C items -> Aisles 7-8, Levels 4-5 (high bay storage)
  const handleCalculatePutaway = (skuId: string) => {
    const sku = skus.find((s) => s.id === skuId);
    if (!sku) return;

    let candidateBins = bins.filter((b) => !b.skuId || b.skuId === skuId);

    if (sku.unitWeightKg > 10) {
      // Must be level 1
      candidateBins = candidateBins.filter((b) => b.level === 1);
    } else if (sku.velocityClass === 'A') {
      candidateBins = candidateBins.filter((b) => b.aisle <= 3 && b.level <= 2);
    } else if (sku.velocityClass === 'C') {
      candidateBins = candidateBins.filter((b) => b.aisle >= 6);
    }

    const bestBin = candidateBins[0] || bins[0];
    setSuggestedBin(bestBin);
  };

  const handleConfirmPutaway = () => {
    if (!suggestedBin || !selectedReceiveSku) return;
    onReceiveAndPutaway(selectedReceiveSku.id, receiveQuantity, suggestedBin.id);
    playScanSuccess(audioEnabled);
    setShowPutawayModal(false);
    setSuggestedBin(null);
  };

  // Filtered SKUs
  const filteredSkus = skus.filter((sku) => {
    const matchesSearch =
      sku.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sku.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sku.binId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sku.barcode.includes(searchTerm);

    const matchesVelocity = velocityFilter === 'ALL' || sku.velocityClass === velocityFilter;
    return matchesSearch && matchesVelocity;
  });

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      {/* Top Header & Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[280px]">
          <div className="relative flex-1 max-w-md">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search SKU ID, Description, Bin Location, or Barcode..."
              className="w-full bg-slate-950 text-slate-200 text-xs pl-9 pr-3.5 py-2 rounded border border-slate-800 focus:outline-none focus:border-cyan-500 font-mono"
            />
          </div>

          {/* Velocity Class Filter Buttons */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded border border-slate-800 text-xs">
            <button
              onClick={() => setVelocityFilter('ALL')}
              className={`px-2.5 py-1 rounded transition-colors ${
                velocityFilter === 'ALL' ? 'bg-cyan-500/20 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Classes
            </button>
            <button
              onClick={() => setVelocityFilter('A')}
              className={`px-2.5 py-1 rounded transition-colors ${
                velocityFilter === 'A' ? 'bg-red-500/20 text-red-300 font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Class A (Fast)
            </button>
            <button
              onClick={() => setVelocityFilter('B')}
              className={`px-2.5 py-1 rounded transition-colors ${
                velocityFilter === 'B' ? 'bg-amber-500/20 text-amber-300 font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Class B (Med)
            </button>
            <button
              onClick={() => setVelocityFilter('C')}
              className={`px-2.5 py-1 rounded transition-colors ${
                velocityFilter === 'C' ? 'bg-blue-500/20 text-blue-300 font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Class C (Slow)
            </button>
          </div>
        </div>

        {/* Primary Action: Dock-to-Stock Inbound Putaway */}
        <button
          onClick={() => {
            setShowPutawayModal(true);
            handleCalculatePutaway(selectedReceiveSkuId);
          }}
          className="px-3.5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-sm"
        >
          <ArrowDownToLine size={14} />
          <span>Inbound Dock-to-Stock Putaway</span>
        </button>
      </div>

      {/* Real-Time Stock Matrix Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Box size={16} className="text-cyan-400" />
            <h3 className="text-sm font-semibold text-slate-200">
              Facility Stock Registry & Bin Allocation
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {filteredSkus.length} of {skus.length} SKUs Listed
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-slate-400 font-mono bg-slate-950/60 border-b border-slate-800">
              <tr>
                <th className="p-2.5">SKU & Item Name</th>
                <th className="p-2.5">Category</th>
                <th className="p-2.5">Velocity</th>
                <th className="p-2.5">Bin Slot</th>
                <th className="p-2.5 text-right">On-Hand</th>
                <th className="p-2.5 text-right">Allocated</th>
                <th className="p-2.5 text-right">Available</th>
                <th className="p-2.5">Barcode (GTIN)</th>
                <th className="p-2.5 text-right">Stock Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono">
              {filteredSkus.map((sku) => {
                const isLow = sku.available <= sku.reorderPoint;

                return (
                  <tr key={sku.id} className="hover:bg-slate-850">
                    <td className="p-2.5">
                      <span className="font-semibold text-cyan-400 block">
                        {sku.id}
                      </span>
                      <span className="text-xs text-slate-300 font-sans">
                        {sku.name} ({sku.unitWeightKg} kg)
                      </span>
                    </td>

                    <td className="p-2.5 text-slate-400 font-sans">
                      {sku.category}
                    </td>

                    <td className="p-2.5">
                      <span
                        className={`px-1.5 py-0.5 rounded text-xs font-semibold ${
                          sku.velocityClass === 'A'
                            ? 'bg-red-950 text-red-300 border border-red-800'
                            : sku.velocityClass === 'B'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-blue-950 text-blue-300 border border-blue-800'
                        }`}
                      >
                        Class {sku.velocityClass}
                      </span>
                    </td>

                    <td className="p-2.5 font-semibold text-slate-200">
                      {sku.binId}
                    </td>

                    <td className="p-2.5 text-right text-slate-200 tabular-nums">
                      {sku.onHand}
                    </td>

                    <td className="p-2.5 text-right text-amber-400 tabular-nums">
                      {sku.allocated}
                    </td>

                    <td className="p-2.5 text-right tabular-nums">
                      <span
                        className={`font-semibold ${
                          isLow ? 'text-red-400' : 'text-emerald-400'
                        }`}
                      >
                        {sku.available}
                      </span>
                    </td>

                    <td className="p-2.5 text-slate-400">
                      {sku.barcode}
                    </td>

                    <td className="p-2.5 text-right font-sans">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onUpdateStock(sku.id, 10)}
                          className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono transition-colors"
                          title="Restock +10"
                        >
                          +10
                        </button>
                        <button
                          onClick={() => onUpdateStock(sku.id, -5)}
                          className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono transition-colors"
                          title="Cycle Pick -5"
                        >
                          -5
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Dock-to-Stock Putaway Modal Dialog */}
      {showPutawayModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg max-w-lg w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ArrowDownToLine size={16} className="text-cyan-400" />
                <h3 className="text-sm font-semibold text-slate-100">
                  Algorithmic Putaway & Slotting Engine
                </h3>
              </div>
              <button
                onClick={() => setShowPutawayModal(false)}
                className="text-slate-400 hover:text-slate-200 text-xs font-mono"
              >
                ✕ Close
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Select Inbound SKU:</label>
                <select
                  value={selectedReceiveSkuId}
                  onChange={(e) => {
                    setSelectedReceiveSkuId(e.target.value);
                    handleCalculatePutaway(e.target.value);
                  }}
                  className="w-full bg-slate-950 text-slate-200 border border-slate-700 rounded p-2 font-mono text-xs focus:outline-none focus:border-cyan-500"
                >
                  {skus.map((sku) => (
                    <option key={sku.id} value={sku.id}>
                      {sku.id} — {sku.name} (Class {sku.velocityClass} · {sku.unitWeightKg}kg)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Inbound Pallet Quantity:</label>
                <input
                  type="number"
                  min="1"
                  max="500"
                  value={receiveQuantity}
                  onChange={(e) => setReceiveQuantity(parseInt(e.target.value, 10) || 1)}
                  className="w-full bg-slate-950 text-slate-200 border border-slate-700 rounded p-2 font-mono text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>

              {/* Algorithmic Putaway Recommendation Box */}
              {suggestedBin && (
                <div className="bg-cyan-950/40 border border-cyan-800/80 rounded p-3.5 space-y-2">
                  <span className="text-xs font-semibold text-cyan-300 flex items-center gap-1.5">
                    <CheckCircle size={14} className="text-cyan-400" />
                    <span>Calculated Optimal Slot: {suggestedBin.id}</span>
                  </span>
                  <div className="grid grid-cols-3 gap-2 pt-1 font-mono text-xs">
                    <div>
                      <span className="text-slate-400 block">Aisle / Bay</span>
                      <span className="text-slate-200">A0{suggestedBin.aisle} · B0{suggestedBin.bay}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Vertical Tier</span>
                      <span className="text-slate-200">Level {suggestedBin.level}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Travel Score</span>
                      <span className="text-emerald-400 font-semibold">98.4 / 100</span>
                    </div>
                  </div>
                  <p className="text-xs text-slate-300 font-sans pt-1">
                    Rule satisfied: Placed in high-efficiency golden zone to minimize walking distance to Central Packing Line.
                  </p>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setShowPutawayModal(false)}
                className="px-3.5 py-1.5 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmPutaway}
                className="px-4 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                <CheckCircle size={14} />
                <span>Confirm Putaway to Bin</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
