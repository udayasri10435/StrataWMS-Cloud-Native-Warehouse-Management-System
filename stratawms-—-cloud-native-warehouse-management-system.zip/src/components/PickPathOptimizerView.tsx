import React, { useState, useEffect } from 'react';
import { PickWave, PathAnalysis, PickItem, AutonomousRobot } from '../types/wms';
import { Play, Pause, RotateCcw, CheckCircle, Navigation, TrendingDown, Clock, CornerDownRight, Bot } from 'lucide-react';
import { playScanSuccess } from '../utils/audio';

interface PickPathOptimizerViewProps {
  waves: PickWave[];
  activeWaveId: string;
  onSelectWave: (waveId: string) => void;
  activePathAnalysis: PathAnalysis;
  legacyPathAnalysis: PathAnalysis;
  congestedAisles: number[];
  onToggleCongestion: (aisle: number) => void;
  audioEnabled: boolean;
  robots: AutonomousRobot[];
  onAssignWaveToRobot: (waveId: string, robotId: string) => void;
}

export const PickPathOptimizerView: React.FC<PickPathOptimizerViewProps> = ({
  waves,
  activeWaveId,
  onSelectWave,
  activePathAnalysis,
  legacyPathAnalysis,
  congestedAisles,
  onToggleCongestion,
  audioEnabled,
  robots,
  onAssignWaveToRobot,
}) => {
  const currentWave = waves.find((w) => w.id === activeWaveId) || waves[0];
  const [isSimulating, setIsSimulating] = useState(false);
  const [currentStepIdx, setCurrentStepIdx] = useState(0);
  const [completedItems, setCompletedItems] = useState<string[]>([]);

  // Calculate percentage savings
  const distanceSavedMeters = legacyPathAnalysis.totalDistanceMeters - activePathAnalysis.totalDistanceMeters;
  const distanceSavingsPct = legacyPathAnalysis.totalDistanceMeters > 0
    ? Math.round((distanceSavedMeters / legacyPathAnalysis.totalDistanceMeters) * 100)
    : 0;

  const timeSavedSeconds = legacyPathAnalysis.estimatedTimeSeconds - activePathAnalysis.estimatedTimeSeconds;
  const timeSavingsPct = legacyPathAnalysis.estimatedTimeSeconds > 0
    ? Math.round((timeSavedSeconds / legacyPathAnalysis.estimatedTimeSeconds) * 100)
    : 0;

  // Simulation timer
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (isSimulating) {
      timer = setInterval(() => {
        setCurrentStepIdx((prev) => {
          if (prev >= activePathAnalysis.path.length - 1) {
            setIsSimulating(false);
            return prev;
          }
          const nextIdx = prev + 1;
          const nextPoint = activePathAnalysis.path[nextIdx];
          if (nextPoint && nextPoint.type === 'PICK' && nextPoint.binId) {
            setCompletedItems((items) => [...items, nextPoint.binId!]);
            playScanSuccess(audioEnabled);
          }
          return nextIdx;
        });
      }, 1400);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isSimulating, activePathAnalysis, audioEnabled]);

  const handleResetSimulation = () => {
    setIsSimulating(false);
    setCurrentStepIdx(0);
    setCompletedItems([]);
  };

  const handleManualPickToggle = (binId: string) => {
    setCompletedItems((prev) =>
      prev.includes(binId) ? prev.filter((id) => id !== binId) : [...prev, binId]
    );
    playScanSuccess(audioEnabled);
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      {/* Wave Selector & Simulation Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <span className="text-xs font-semibold text-slate-400 font-mono">
            SELECT ACTIVE WAVE:
          </span>
          <div className="flex items-center gap-1.5">
            {waves.map((wave) => (
              <button
                key={wave.id}
                onClick={() => {
                  onSelectWave(wave.id);
                  handleResetSimulation();
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                  wave.id === activeWaveId
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                    : 'bg-slate-950 text-slate-400 border border-slate-850 hover:text-slate-200'
                }`}
              >
                {wave.id} ({wave.items.length} picks)
              </button>
            ))}
          </div>
          <span className="text-xs text-slate-400">
            Order: <span className="text-slate-200 font-mono font-medium">{currentWave.orderNumber}</span>
          </span>
        </div>

        {/* Play / Pause / Reset Simulation Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsSimulating(!isSimulating)}
            className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              isSimulating
                ? 'bg-amber-600 hover:bg-amber-500 text-white'
                : 'bg-cyan-600 hover:bg-cyan-500 text-white'
            }`}
          >
            {isSimulating ? <Pause size={14} /> : <Play size={14} />}
            <span>{isSimulating ? 'Pause Pick Run' : 'Simulate Pick Run'}</span>
          </button>
          <button
            onClick={handleResetSimulation}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 transition-colors"
            title="Reset Simulation"
          >
            <RotateCcw size={14} />
          </button>
        </div>
      </div>

      {/* Side-by-Side Benchmark: Legacy S-Shape vs Strata Optimized TSP */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Legacy On-Prem S-Shape Benchmark Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <span className="text-sm font-semibold text-slate-200">
                  Legacy WMS: Standard S-Shape Traversal
                </span>
              </div>
              <span className="text-xs font-mono text-slate-400">Fixed Pattern</span>
            </div>

            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Standard legacy on-prem routing. Forces pickers and AGVs to traverse entire aisles regardless of pick density, causing severe deadhead walking and congestion bottlenecks.
            </p>

            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="bg-slate-950 p-3 rounded border border-slate-850">
                <span className="text-xs text-slate-400 block mb-0.5">Total Distance</span>
                <span className="text-xl font-bold font-mono text-slate-200 tabular-nums">
                  {legacyPathAnalysis.totalDistanceMeters}m
                </span>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-850">
                <span className="text-xs text-slate-400 block mb-0.5">Est. Time</span>
                <span className="text-xl font-bold font-mono text-slate-200 tabular-nums">
                  {Math.floor(legacyPathAnalysis.estimatedTimeSeconds / 60)}m {legacyPathAnalysis.estimatedTimeSeconds % 60}s
                </span>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-850">
                <span className="text-xs text-slate-400 block mb-0.5">90° Turns</span>
                <span className="text-xl font-bold font-mono text-amber-400 tabular-nums">
                  {legacyPathAnalysis.turnCount}
                </span>
              </div>
            </div>
          </div>

          <div className="text-xs text-slate-400 font-mono bg-slate-950/70 p-2.5 rounded border border-slate-850">
            Routing Model: Strict Aisle-by-Aisle Sweep (Zero cross-cut usage)
          </div>
        </div>

        {/* Strata Modern Algorithmic TSP Benchmark Card */}
        <div className="bg-slate-900 border border-cyan-500/40 rounded-lg p-5 flex flex-col justify-between shadow-lg shadow-cyan-950/20">
          <div>
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
                <span className="text-sm font-semibold text-white">
                  Strata Modern: Dynamic Graph TSP Optimizer
                </span>
              </div>
              <div className="flex items-center gap-1 text-xs font-mono text-cyan-400 font-semibold bg-cyan-950/50 px-2 py-0.5 rounded border border-cyan-800">
                <TrendingDown size={13} />
                <span>-{distanceSavingsPct}% Travel</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              Cloud-native graph engine with 2-opt heuristic, dynamic middle cross-aisle bypasses, turn minimization, and live AGV congestion rerouting.
            </p>

            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="bg-slate-950 p-3 rounded border border-slate-850">
                <span className="text-xs text-slate-400 block mb-0.5">Total Distance</span>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-xl font-bold font-mono text-cyan-400 tabular-nums">
                    {activePathAnalysis.totalDistanceMeters}m
                  </span>
                  <span className="text-xs text-emerald-400 font-mono">(-{distanceSavedMeters}m)</span>
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-850">
                <span className="text-xs text-slate-400 block mb-0.5">Est. Time</span>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-xl font-bold font-mono text-cyan-400 tabular-nums">
                    {Math.floor(activePathAnalysis.estimatedTimeSeconds / 60)}m {activePathAnalysis.estimatedTimeSeconds % 60}s
                  </span>
                  <span className="text-xs text-emerald-400 font-mono">(-{Math.floor(timeSavedSeconds / 60)}m)</span>
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-850">
                <span className="text-xs text-slate-400 block mb-0.5">90° Turns</span>
                <span className="text-xl font-bold font-mono text-cyan-400 tabular-nums">
                  {activePathAnalysis.turnCount}
                </span>
              </div>
            </div>
          </div>

          {/* Dynamic Congestion Reroute Alert */}
          {congestedAisles.length > 0 ? (
            <div className="text-xs text-amber-300 bg-amber-950/40 p-2.5 rounded border border-amber-800/60 flex items-center justify-between">
              <span>Aisle(s) {congestedAisles.join(', ')} congested: Route dynamically shifted via Central Crossway.</span>
              <button
                onClick={() => onToggleCongestion(congestedAisles[0])}
                className="text-amber-200 underline text-xs font-mono ml-2 shrink-0 hover:text-white"
              >
                Clear
              </button>
            </div>
          ) : (
            <div className="text-xs text-emerald-300 bg-emerald-950/30 p-2.5 rounded border border-emerald-800/40 flex items-center justify-between">
              <span>All warehouse aisles free of congestion. Optimal path locked.</span>
              <button
                onClick={() => onToggleCongestion(3)}
                className="text-xs text-slate-400 hover:text-slate-200 underline"
              >
                Simulate Block in A3
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Turn-by-Turn Pick Sequence Execution */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">
              Turn-by-Turn Waypoint Sequence
            </h3>
            <span className="text-xs text-slate-400">
              Wave {currentWave.id} · {completedItems.length} of {currentWave.items.length} items verified
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-mono">Assign Fleet:</span>
            <select
              value={currentWave.assignedAmrId || ''}
              onChange={(e) => onAssignWaveToRobot(currentWave.id, e.target.value)}
              className="bg-slate-950 text-slate-200 border border-slate-800 text-xs rounded px-2.5 py-1 font-mono focus:outline-none focus:border-cyan-500"
            >
              <option value="">Manual Human Picker</option>
              {robots.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.id} ({r.name} - {r.batteryPercent}%)
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Waypoint steps table/list */}
        <div className="divide-y divide-slate-800/80">
          {activePathAnalysis.path.map((point, idx) => {
            const isCurrent = idx === currentStepIdx;
            const isPick = point.type === 'PICK';
            const isCompleted = point.binId ? completedItems.includes(point.binId) : false;

            return (
              <div
                key={`step-${idx}`}
                className={`py-3 px-3 rounded flex items-center justify-between gap-3 text-xs transition-colors ${
                  isCurrent
                    ? 'bg-cyan-950/40 border border-cyan-800/80'
                    : 'hover:bg-slate-850'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 text-center font-mono text-slate-500 tabular-nums">
                    {idx + 1}
                  </span>

                  <div className="flex items-center gap-2">
                    {point.type === 'START' && (
                      <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-xs">START</span>
                    )}
                    {point.type === 'TRANSIT' && (
                      <CornerDownRight size={13} className="text-slate-500" />
                    )}
                    {point.type === 'PICK' && (
                      <span className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono text-xs font-semibold">
                        PICK
                      </span>
                    )}
                    {point.type === 'END' && (
                      <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono text-xs">DEST</span>
                    )}

                    <span className="text-slate-200 font-medium">{point.instruction}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  {point.binId && (
                    <span className="font-mono text-cyan-400 font-semibold">{point.binId}</span>
                  )}

                  {isPick && point.binId && (
                    <button
                      onClick={() => handleManualPickToggle(point.binId!)}
                      className={`px-2.5 py-1 rounded text-xs font-medium transition-colors flex items-center gap-1.5 ${
                        isCompleted
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <CheckCircle size={13} className={isCompleted ? 'text-emerald-400' : 'text-slate-500'} />
                      <span>{isCompleted ? 'Verified' : 'Confirm Pick'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
