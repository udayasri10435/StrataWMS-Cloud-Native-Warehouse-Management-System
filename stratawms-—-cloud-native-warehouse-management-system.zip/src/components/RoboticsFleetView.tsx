import React, { useState } from 'react';
import { AutonomousRobot, AmrStatus, PickWave } from '../types/wms';
import { Bot, Battery, BatteryCharging, AlertTriangle, Play, Pause, Navigation, Shield, Zap, Send, RotateCw } from 'lucide-react';
import { AISLE_X_COORDS, CROSS_AISLE_Y, PACKING_STATION, INBOUND_DOCK } from '../utils/pickPathOptimizer';

interface RoboticsFleetViewProps {
  robots: AutonomousRobot[];
  waves: PickWave[];
  onDispatchRobot: (robotId: string, targetX: number, targetY: number, waypointName: string) => void;
  onToggleRobotEStop: (robotId: string) => void;
  onSendToCharge: (robotId: string) => void;
  onAssignWaveToRobot: (waveId: string, robotId: string) => void;
}

export const RoboticsFleetView: React.FC<RoboticsFleetViewProps> = ({
  robots,
  waves,
  onDispatchRobot,
  onToggleRobotEStop,
  onSendToCharge,
  onAssignWaveToRobot,
}) => {
  const [selectedRobotId, setSelectedRobotId] = useState<string>(robots[0]?.id || 'AMR-101');
  const [customWaypoint, setCustomWaypoint] = useState<string>('PACKING');

  const selectedRobot = robots.find((r) => r.id === selectedRobotId) || robots[0];

  const handleDispatchSelected = () => {
    if (!selectedRobot) return;
    if (customWaypoint === 'PACKING') {
      onDispatchRobot(selectedRobot.id, PACKING_STATION.x, PACKING_STATION.y, 'Packing Station Central');
    } else if (customWaypoint === 'INBOUND') {
      onDispatchRobot(selectedRobot.id, INBOUND_DOCK.x, INBOUND_DOCK.y, 'Inbound Dock 01');
    } else if (customWaypoint === 'AISLE_4') {
      onDispatchRobot(selectedRobot.id, AISLE_X_COORDS[4], CROSS_AISLE_Y.MID, 'Aisle 04 Mid-Cutway');
    } else if (customWaypoint === 'AISLE_7') {
      onDispatchRobot(selectedRobot.id, AISLE_X_COORDS[7], CROSS_AISLE_Y.BOT, 'Aisle 07 South Concourse');
    } else if (customWaypoint === 'CHARGE') {
      onSendToCharge(selectedRobot.id);
    }
  };

  // Fleet summary stats
  const activeCount = robots.filter((r) => r.status === 'NAVIGATING' || r.status === 'PICKING').length;
  const chargingCount = robots.filter((r) => r.status === 'CHARGING').length;
  const alertCount = robots.filter((r) => r.status === 'ALERT' || r.lidarObstacleDetected).length;

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      {/* Fleet Command Header & KPI Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5">
          <span className="text-xs text-slate-400 block mb-1">Fleet Total</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-100 tabular-nums">
              {robots.length}
            </span>
            <span className="text-xs text-slate-400 font-mono">AMRs/AGVs</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5">
          <span className="text-xs text-slate-400 block mb-1">Active Missions</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">
              {activeCount}
            </span>
            <span className="text-xs text-emerald-400 font-mono">In Transit</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5">
          <span className="text-xs text-slate-400 block mb-1">Inductive Charging</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-amber-400 tabular-nums">
              {chargingCount}
            </span>
            <span className="text-xs text-slate-400 font-mono">Pads Engaged</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5">
          <span className="text-xs text-slate-400 block mb-1">LiDAR Safety Alerts</span>
          <div className="flex items-baseline gap-2">
            <span className={`text-2xl font-bold font-mono tabular-nums ${alertCount > 0 ? 'text-red-400' : 'text-slate-300'}`}>
              {alertCount}
            </span>
            <span className="text-xs text-slate-400 font-mono">Zones Cleared</span>
          </div>
        </div>
      </div>

      {/* Main Fleet Matrix & Dispatch Console */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Robot Fleet Table / List */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Bot size={16} className="text-cyan-400" />
              <span className="text-sm font-semibold text-slate-200">
                Autonomous Mobile Robots Telemetry
              </span>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              ROS 2 / Open-RMF VDA-5050 Protocol
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-slate-400 font-mono bg-slate-950/60 border-b border-slate-800">
                <tr>
                  <th className="p-2.5">Robot Unit</th>
                  <th className="p-2.5">Type & Chassis</th>
                  <th className="p-2.5">Status</th>
                  <th className="p-2.5">Battery</th>
                  <th className="p-2.5">Speed / Payload</th>
                  <th className="p-2.5">Target Destination</th>
                  <th className="p-2.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 font-mono">
                {robots.map((robot) => {
                  const isSelected = selectedRobotId === robot.id;
                  const isBlocked = robot.lidarObstacleDetected;

                  return (
                    <tr
                      key={robot.id}
                      onClick={() => setSelectedRobotId(robot.id)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-cyan-950/30' : 'hover:bg-slate-850'
                      }`}
                    >
                      <td className="p-2.5">
                        <span className="font-semibold text-slate-200 block">
                          {robot.id}
                        </span>
                        <span className="text-xs text-slate-400 font-sans">
                          {robot.name}
                        </span>
                      </td>

                      <td className="p-2.5 text-slate-300">
                        {robot.type === 'PALLET_AMR' && 'Pallet Lifter 1.2t'}
                        {robot.type === 'SHELF_CARRIER' && 'Tote Shelf Carrier'}
                        {robot.type === 'TUGGER_TRAIN' && 'Tugger Train 2.0t'}
                      </td>

                      <td className="p-2.5">
                        <span
                          className={`px-1.5 py-0.5 rounded text-xs font-semibold ${
                            isBlocked
                              ? 'bg-red-950 text-red-300 border border-red-800'
                              : robot.status === 'NAVIGATING'
                              ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                              : robot.status === 'CHARGING'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : robot.status === 'PICKING'
                              ? 'bg-indigo-950 text-indigo-300 border border-indigo-800'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {isBlocked ? 'OBSTACLE STOP' : robot.status}
                        </span>
                      </td>

                      <td className="p-2.5">
                        <div className="flex items-center gap-1.5">
                          {robot.status === 'CHARGING' ? (
                            <BatteryCharging size={13} className="text-amber-400 animate-pulse" />
                          ) : (
                            <Battery size={13} className={robot.batteryPercent < 25 ? 'text-red-400' : 'text-emerald-400'} />
                          )}
                          <span
                            className={`tabular-nums ${
                              robot.batteryPercent < 25 ? 'text-red-400 font-semibold' : 'text-slate-200'
                            }`}
                          >
                            {robot.batteryPercent}%
                          </span>
                        </div>
                      </td>

                      <td className="p-2.5 text-slate-300">
                        <span>{robot.velocityMps} m/s</span>
                        <span className="text-slate-500"> · </span>
                        <span>{robot.payloadKg}kg</span>
                      </td>

                      <td className="p-2.5 text-slate-300 truncate max-w-[140px]">
                        {robot.targetWaypoint || 'Idle at Concourse'}
                      </td>

                      <td className="p-2.5 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleRobotEStop(robot.id);
                          }}
                          className={`px-2 py-0.5 rounded text-xs ${
                            robot.status === 'ALERT'
                              ? 'bg-emerald-900 text-emerald-200'
                              : 'bg-red-950/80 text-red-300 hover:bg-red-900'
                          }`}
                        >
                          {robot.status === 'ALERT' ? 'Resume' : 'E-Stop'}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Selected Robot Mission Dispatch Console */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div>
                <span className="text-xs font-mono text-cyan-400 block">SELECTED UNIT</span>
                <h3 className="text-sm font-semibold text-slate-100">
                  {selectedRobot.id} · {selectedRobot.name}
                </h3>
              </div>
              <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
                Connected
              </span>
            </div>

            {/* Quick stats for selected unit */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-950 p-2.5 rounded border border-slate-850">
                <span className="text-slate-500 block">Chassis Position</span>
                <span className="font-mono text-slate-200">
                  X:{selectedRobot.x} · Y:{selectedRobot.y}
                </span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded border border-slate-850">
                <span className="text-slate-500 block">Payload Load</span>
                <span className="font-mono text-slate-200">
                  {selectedRobot.payloadKg} / {selectedRobot.maxPayloadKg} kg
                </span>
              </div>
            </div>

            {/* Mission Dispatch Controls */}
            <div className="space-y-3 pt-2 border-t border-slate-800">
              <span className="text-xs font-semibold text-slate-400 font-mono block">
                MISSION DISPATCH & ROUTING:
              </span>

              <div>
                <label className="text-xs text-slate-400 block mb-1">
                  Target Waypoint Concourse:
                </label>
                <select
                  value={customWaypoint}
                  onChange={(e) => setCustomWaypoint(e.target.value)}
                  className="w-full bg-slate-950 text-slate-200 border border-slate-700 text-xs rounded px-3 py-2 font-mono focus:outline-none focus:border-cyan-500"
                >
                  <option value="PACKING">Packing Station Central (Wave Drop)</option>
                  <option value="INBOUND">Inbound Dock 01 (RFID Portal Gate)</option>
                  <option value="AISLE_4">Aisle 04 Mid-Cutway (Putaway)</option>
                  <option value="AISLE_7">Aisle 07 South Concourse</option>
                  <option value="CHARGE">Fast-Charge Inductive Bay 01</option>
                </select>
              </div>

              <button
                onClick={handleDispatchSelected}
                className="w-full py-2 px-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
              >
                <Send size={13} />
                <span>Transmit Mission Waypoint</span>
              </button>
            </div>

            {/* Fast-Charge & E-Stop Quick Buttons */}
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => onSendToCharge(selectedRobot.id)}
                className="py-1.5 px-2 bg-amber-950/40 hover:bg-amber-900/50 text-amber-300 border border-amber-800 rounded text-xs font-medium transition-colors flex items-center justify-center gap-1"
              >
                <Zap size={13} />
                <span>Return to Charger</span>
              </button>

              <button
                onClick={() => onToggleRobotEStop(selectedRobot.id)}
                className="py-1.5 px-2 bg-red-950/40 hover:bg-red-900/50 text-red-300 border border-red-800 rounded text-xs font-medium transition-colors flex items-center justify-center gap-1"
              >
                <AlertTriangle size={13} />
                <span>Emergency Hold</span>
              </button>
            </div>
          </div>

          <div className="mt-4 p-3 bg-slate-950 rounded border border-slate-800 text-xs text-slate-400">
            <span className="font-semibold text-slate-300 block mb-1">
              Multi-Agent Orchestration
            </span>
            StrataWMS coordinates heterogenous robot fleets (Kiva, MiR, OTTO, Fetch) over standard VDA 5050 without vendor lock-in.
          </div>
        </div>
      </div>
    </div>
  );
};
