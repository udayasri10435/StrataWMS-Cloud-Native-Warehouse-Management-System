import React, { useState, useRef } from 'react';
import { InventoryItem, RFIDTagRead, AsnManifestItem, ScanLogEntry } from '../types/wms';
import { playScanSuccess, playScanError, playRfidChirp } from '../utils/audio';
import { Scan, Radio, CheckCircle2, AlertOctagon, RotateCcw, ArrowRight, ShieldCheck, Tag } from 'lucide-react';

interface ScannerHubProps {
  skus: InventoryItem[];
  audioEnabled: boolean;
  onUpdateSkuStock: (skuId: string, delta: number) => void;
  asnManifest: AsnManifestItem[];
}

export const ScannerHub: React.FC<ScannerHubProps> = ({
  skus,
  audioEnabled,
  onUpdateSkuStock,
  asnManifest,
}) => {
  const [activeScannerMode, setActiveScannerMode] = useState<'GUN' | 'PORTAL'>('GUN');

  // Gun scanner state
  const [barcodeInput, setBarcodeInput] = useState('');
  const [scanResult, setScanResult] = useState<{
    success: boolean;
    message: string;
    decodedSku?: InventoryItem;
    gs1Ai?: { gtin?: string; lot?: string; serial?: string };
  } | null>(null);
  const [isLaserActive, setIsLaserActive] = useState(false);

  // RFID Portal state
  const [rfidReads, setRfidReads] = useState<RFIDTagRead[]>([]);
  const [isPortalScanning, setIsPortalScanning] = useState(false);
  const [manifestState, setManifestState] = useState<AsnManifestItem[]>(asnManifest);

  // Scan log
  const [scanLogs, setScanLogs] = useState<ScanLogEntry[]>([
    {
      id: 'LOG-01',
      type: 'BARCODE',
      code: '01008472910482',
      details: 'SKU-DRV-8490 Pick Verification at A03-B02-L2',
      success: true,
      timestamp: '14:22:08',
      operator: 'OP-4491 (J. Miller)',
    },
    {
      id: 'LOG-02',
      type: 'RFID',
      code: 'E28011606000020812A4F901',
      details: 'Gate 01 Inbound Portal Read (-48 dBm, Ant 2)',
      success: true,
      timestamp: '14:20:41',
      operator: 'GATEWAY-01 AUTO',
    },
  ]);

  const barcodeInputRef = useRef<HTMLInputElement>(null);

  // Process barcode scan
  const handleProcessBarcode = (code: string) => {
    const cleanCode = code.trim();
    if (!cleanCode) return;

    setIsLaserActive(true);
    setTimeout(() => setIsLaserActive(false), 300);

    // Look for matching SKU by barcode or id
    const found = skus.find(
      (s) => s.barcode === cleanCode || s.id.toLowerCase() === cleanCode.toLowerCase()
    );

    if (found) {
      playScanSuccess(audioEnabled);
      setScanResult({
        success: true,
        message: `Verified: ${found.name} (${found.id})`,
        decodedSku: found,
        gs1Ai: {
          gtin: found.barcode,
          lot: `LOT-${Math.floor(1000 + Math.random() * 9000)}`,
          serial: `SN-${found.rfidEpc.slice(-6)}`,
        },
      });

      // Add to log
      setScanLogs((prev) => [
        {
          id: `LOG-${Date.now().toString().slice(-4)}`,
          type: 'BARCODE',
          code: cleanCode,
          details: `${found.id} verified at ${found.binId}`,
          success: true,
          timestamp: new Date().toLocaleTimeString(),
          operator: 'OP-WEDGE-GUN',
        },
        ...prev.slice(0, 19),
      ]);
    } else {
      playScanError(audioEnabled);
      setScanResult({
        success: false,
        message: `Unknown barcode "${cleanCode}". Not indexed in current facility catalog.`,
      });

      setScanLogs((prev) => [
        {
          id: `LOG-${Date.now().toString().slice(-4)}`,
          type: 'BARCODE',
          code: cleanCode,
          details: 'Unregistered barcode reject',
          success: false,
          timestamp: new Date().toLocaleTimeString(),
          operator: 'OP-WEDGE-GUN',
        },
        ...prev.slice(0, 19),
      ]);
    }

    setBarcodeInput('');
    barcodeInputRef.current?.focus();
  };

  // Simulate bulk RFID portal gate scan (e.g. pallet passing through dock door antenna array)
  const handleTriggerRfidPortal = () => {
    setIsPortalScanning(true);
    playRfidChirp(audioEnabled);

    // Generate burst of 15-25 tags from current SKUs
    const burstCount = 18;
    const newReads: RFIDTagRead[] = [];
    const updatedManifest = [...manifestState];

    for (let i = 0; i < burstCount; i++) {
      const randomSku = skus[Math.floor(Math.random() * skus.length)];
      const epc = `${randomSku.rfidEpc.slice(0, 18)}${Math.floor(100000 + Math.random() * 900000).toString(16).toUpperCase()}`;
      const antenna = Math.floor(Math.random() * 4) + 1;
      const rssi = -Math.floor(40 + Math.random() * 32); // -40 to -72 dBm

      // Check manifest match
      const manifestItem = updatedManifest.find((m) => m.sku === randomSku.id);
      let status: 'MATCHED' | 'UNEXPECTED' | 'DISCREPANCY' = 'MATCHED';

      if (manifestItem) {
        manifestItem.scannedQty += 1;
      } else {
        status = 'UNEXPECTED';
      }

      newReads.push({
        epc,
        sku: randomSku.id,
        description: randomSku.name,
        antennaId: antenna,
        rssiDb: rssi,
        timestamp: new Date().toLocaleTimeString(),
        status,
      });
    }

    setTimeout(() => {
      setRfidReads(newReads);
      setManifestState(updatedManifest);
      setIsPortalScanning(false);
      playScanSuccess(audioEnabled);

      // Add to log
      setScanLogs((prev) => [
        {
          id: `LOG-${Date.now().toString().slice(-4)}`,
          type: 'RFID',
          code: `PORTAL-GATE-01 (${burstCount} tags)`,
          details: `Pallet pass-through: ${burstCount} EPC Gen2 tags captured in 320ms`,
          success: true,
          timestamp: new Date().toLocaleTimeString(),
          operator: 'RFID-PORTAL-DOCK01',
        },
        ...prev.slice(0, 19),
      ]);
    }, 450);
  };

  const handleResetManifest = () => {
    setManifestState(asnManifest.map((m) => ({ ...m, scannedQty: 0 })));
    setRfidReads([]);
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      {/* Scanner Mode Selector Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold text-slate-400 font-mono">
            CAPTURE INTERFACE:
          </span>
          <div className="flex items-center bg-slate-950 p-1 rounded border border-slate-800">
            <button
              onClick={() => setActiveScannerMode('GUN')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors flex items-center gap-1.5 ${
                activeScannerMode === 'GUN'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Scan size={14} />
              <span>Rugged Handheld Gun (1D / 2D)</span>
            </button>

            <button
              onClick={() => setActiveScannerMode('PORTAL')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors flex items-center gap-1.5 ${
                activeScannerMode === 'PORTAL'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Radio size={14} />
              <span>UHF RFID Bulk Portal (Dock 01)</span>
            </button>
          </div>
        </div>

        <div className="text-xs text-slate-400 font-mono flex items-center gap-2">
          <span>Decoder: GS1-128 / EPC Gen2 Class 1</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
        </div>
      </div>

      {/* Main Mode View */}
      {activeScannerMode === 'GUN' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Handheld Gun Simulator Column */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Scan size={16} className="text-cyan-400" />
                <span className="text-sm font-semibold text-slate-200">
                  Zebra / Honeywell Wedge Gun Emulator
                </span>
              </div>
              <span className="text-xs font-mono text-emerald-400 bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-800">
                HID Wedge Ready
              </span>
            </div>

            {/* Simulated Gun Aiming Box */}
            <div className="relative bg-slate-950 rounded-lg border-2 border-dashed border-slate-800 p-6 flex flex-col items-center justify-center min-h-[170px] overflow-hidden">
              {isLaserActive && (
                <div className="absolute inset-x-0 top-1/2 h-0.5 bg-red-500 shadow-[0_0_12px_#ef4444] animate-pulse" />
              )}
              <Scan size={36} className={`mb-2 transition-colors ${isLaserActive ? 'text-red-400' : 'text-slate-600'}`} />
              <span className="text-xs text-slate-400 text-center max-w-sm mb-3">
                Aim at barcode or enter serial/GTIN below. Press Enter to trigger hardware wedge decode.
              </span>

              {/* Wedge Input Field */}
              <div className="w-full max-w-md flex items-center gap-2">
                <input
                  ref={barcodeInputRef}
                  type="text"
                  value={barcodeInput}
                  onChange={(e) => setBarcodeInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleProcessBarcode(barcodeInput);
                    }
                  }}
                  placeholder="Scan or type barcode (e.g. 01008472910482)..."
                  className="flex-1 bg-slate-900 text-white font-mono text-xs px-3.5 py-2.5 rounded border border-slate-700 focus:outline-none focus:border-cyan-500"
                />
                <button
                  onClick={() => handleProcessBarcode(barcodeInput)}
                  className="px-4 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-xs font-semibold transition-colors shrink-0"
                >
                  Scan Trigger
                </button>
              </div>
            </div>

            {/* Quick-Scan Preset Buttons for Testing */}
            <div>
              <span className="text-xs font-semibold text-slate-400 font-mono block mb-2">
                QUICK BARCODE PRESETS (CLICK TO SIMULATE GUN SCAN):
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {skus.slice(0, 4).map((sku) => (
                  <button
                    key={sku.id}
                    onClick={() => handleProcessBarcode(sku.barcode)}
                    className="p-2.5 bg-slate-950 hover:bg-slate-850 border border-slate-800 rounded text-left transition-colors"
                  >
                    <span className="text-xs font-mono text-cyan-400 font-semibold block truncate">
                      {sku.id}
                    </span>
                    <span className="text-xs text-slate-400 font-mono block truncate">
                      {sku.barcode}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Scan Result & GS1 Application Identifiers Breakdown */}
            {scanResult && (
              <div
                className={`p-4 rounded-lg border text-xs ${
                  scanResult.success
                    ? 'bg-cyan-950/30 border-cyan-800 text-slate-200'
                    : 'bg-red-950/30 border-red-800 text-red-200'
                }`}
              >
                <div className="flex items-center gap-2 mb-2 font-semibold">
                  {scanResult.success ? (
                    <CheckCircle2 size={16} className="text-emerald-400" />
                  ) : (
                    <AlertOctagon size={16} className="text-red-400" />
                  )}
                  <span>{scanResult.message}</span>
                </div>

                {scanResult.decodedSku && scanResult.gs1Ai && (
                  <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-800 font-mono">
                    <div className="bg-slate-950/80 p-2 rounded">
                      <span className="text-slate-500 block text-xs">(01) GTIN</span>
                      <span className="text-slate-200 font-semibold">{scanResult.gs1Ai.gtin}</span>
                    </div>
                    <div className="bg-slate-950/80 p-2 rounded">
                      <span className="text-slate-500 block text-xs">(10) LOT</span>
                      <span className="text-cyan-400 font-semibold">{scanResult.gs1Ai.lot}</span>
                    </div>
                    <div className="bg-slate-950/80 p-2 rounded">
                      <span className="text-slate-500 block text-xs">(21) SERIAL</span>
                      <span className="text-emerald-400 font-semibold">{scanResult.gs1Ai.serial}</span>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Gun Scanner Metrics & Audit */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-200 mb-3 pb-2 border-b border-slate-800">
                Scanner Hardware Diagnostics
              </h3>
              <div className="space-y-2.5 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">Device Protocol</span>
                  <span className="font-mono text-slate-200">Bluetooth BLE 5.3 SPP</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">Scan Engine</span>
                  <span className="font-mono text-slate-200">SE4770 2D Imager</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">Symbologies</span>
                  <span className="font-mono text-slate-200">GS1-128, DataMatrix, QR</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">Decode Latency</span>
                  <span className="font-mono text-emerald-400">18ms (Edge Sub-cycle)</span>
                </div>
              </div>
            </div>

            <div className="mt-4 p-3 rounded bg-slate-950 border border-slate-800 text-xs text-slate-400">
              <span className="font-semibold text-slate-300 block mb-1">
                Zero-Footprint Web Integration
              </span>
              Modern Strata WMS communicates natively with barcode wedge scanners via WebHID/keyboard wedge without legacy desktop middleware.
            </div>
          </div>
        </div>
      ) : (
        /* UHF RFID Portal Gate View */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* RFID Portal Controls & Manifest Reconciliation */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Radio size={16} className="text-cyan-400" />
                <span className="text-sm font-semibold text-slate-200">
                  Inbound Dock 01 · Bulk RFID Portal Gate (4-Antenna Array)
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleResetManifest}
                  className="p-1 text-slate-400 hover:text-slate-200"
                  title="Reset Manifest"
                >
                  <RotateCcw size={14} />
                </button>
                <button
                  disabled={isPortalScanning}
                  onClick={handleTriggerRfidPortal}
                  className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 text-white rounded text-xs font-semibold transition-colors flex items-center gap-1.5"
                >
                  <Radio size={13} className={isPortalScanning ? 'animate-spin' : ''} />
                  <span>{isPortalScanning ? 'Reading Array...' : 'Trigger Pallet Portal Pass'}</span>
                </button>
              </div>
            </div>

            {/* Advance Shipping Notice (ASN) Reconciliation Matrix */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-400 font-mono">
                  ASN MANIFEST RECONCILIATION (BOL-99042):
                </span>
                <span className="text-xs text-slate-400">
                  UHF Gen2 EPC 860-960 MHz
                </span>
              </div>

              <div className="overflow-x-auto rounded border border-slate-800">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 font-mono border-b border-slate-800">
                    <tr>
                      <th className="p-2.5">SKU & Item</th>
                      <th className="p-2.5 text-right">Expected</th>
                      <th className="p-2.5 text-right">Scanned</th>
                      <th className="p-2.5 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 bg-slate-900/50">
                    {manifestState.map((item) => {
                      const isComplete = item.scannedQty >= item.expectedQty;
                      return (
                        <tr key={item.sku} className="hover:bg-slate-850">
                          <td className="p-2.5">
                            <span className="font-mono text-cyan-400 font-medium block">
                              {item.sku}
                            </span>
                            <span className="text-slate-400 truncate max-w-xs block text-xs">
                              {item.description}
                            </span>
                          </td>
                          <td className="p-2.5 text-right font-mono text-slate-300 tabular-nums">
                            {item.expectedQty}
                          </td>
                          <td className="p-2.5 text-right font-mono tabular-nums font-semibold text-white">
                            {item.scannedQty}
                          </td>
                          <td className="p-2.5 text-right font-mono">
                            {isComplete ? (
                              <span className="text-emerald-400 font-medium">VERIFIED 100%</span>
                            ) : item.scannedQty > 0 ? (
                              <span className="text-amber-400 font-medium">
                                PARTIAL ({Math.round((item.scannedQty / item.expectedQty) * 100)}%)
                              </span>
                            ) : (
                              <span className="text-slate-500">PENDING SCAN</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Real-time Multi-Tag Stream */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-400 font-mono">
                  LIVE TAG BURST FEED ({rfidReads.length} EPCs CAPTURED):
                </span>
                <span className="text-xs font-mono text-cyan-400">
                  Array Beam Rate: 650 tags/sec
                </span>
              </div>

              {rfidReads.length > 0 ? (
                <div className="max-h-52 overflow-y-auto divide-y divide-slate-850 border border-slate-800 rounded bg-slate-950 font-mono text-xs">
                  {rfidReads.map((tag, idx) => (
                    <div
                      key={`rfid-${idx}`}
                      className="p-2 flex items-center justify-between hover:bg-slate-900"
                    >
                      <div className="flex items-center gap-2">
                        <Tag size={13} className="text-cyan-400 shrink-0" />
                        <span className="text-slate-200 font-semibold">{tag.epc}</span>
                        <span className="text-slate-500">·</span>
                        <span className="text-slate-400 truncate max-w-[140px]">{tag.sku}</span>
                      </div>
                      <div className="flex items-center gap-3 text-slate-400">
                        <span>Ant {tag.antennaId}</span>
                        <span className="text-emerald-400 tabular-nums">{tag.rssiDb} dBm</span>
                        <span className="text-slate-500">{tag.timestamp}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500 text-xs bg-slate-950 rounded border border-slate-800">
                  <Radio size={22} className="mx-auto mb-1.5 opacity-40" />
                  Pallet portal antenna array is standby. Click "Trigger Pallet Portal Pass" to simulate high-speed bulk RFID capture.
                </div>
              )}
            </div>
          </div>

          {/* RFID Portal Hardware Telemetry */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-200 mb-3 pb-2 border-b border-slate-800">
                Portal Antenna Diagnostics
              </h3>
              <div className="space-y-2.5 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">Antenna Array</span>
                  <span className="font-mono text-slate-200">4x Circular Polarized 9dBi</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">Transmit Power</span>
                  <span className="font-mono text-slate-200">+31.5 dBm (Auto-tuned)</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">Anti-Collision</span>
                  <span className="font-mono text-slate-200">Q-Algorithm Dynamic S0-S3</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-850">
                  <span className="text-slate-400">Portal Gate Speed</span>
                  <span className="font-mono text-emerald-400">Up to 15 km/h Forklift Pass</span>
                </div>
              </div>
            </div>

            <div className="mt-4 p-3 rounded bg-slate-950 border border-slate-800 text-xs text-slate-400">
              <span className="font-semibold text-slate-300 block mb-1">
                Dock-to-Stock Instant Ingestion
              </span>
              Bulk RFID portal eliminates line-of-sight manual barcode scanning, checking in an entire 40-case pallet in 400ms.
            </div>
          </div>
        </div>
      )}

      {/* Global Real-Time Scan Event Log */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
          <h3 className="text-sm font-semibold text-slate-200">
            Real-Time Edge Capture Audit Log
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            {scanLogs.length} Events In-Memory
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-slate-400 font-mono bg-slate-950/60 border-b border-slate-800">
              <tr>
                <th className="p-2.5">Time</th>
                <th className="p-2.5">Type</th>
                <th className="p-2.5">Payload / Code</th>
                <th className="p-2.5">Details</th>
                <th className="p-2.5">Operator</th>
                <th className="p-2.5 text-right">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850 font-mono">
              {scanLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-850">
                  <td className="p-2.5 text-slate-400 tabular-nums">{log.timestamp}</td>
                  <td className="p-2.5">
                    <span
                      className={`px-1.5 py-0.5 rounded text-xs ${
                        log.type === 'RFID'
                          ? 'bg-purple-950 text-purple-300 border border-purple-800'
                          : 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                      }`}
                    >
                      {log.type}
                    </span>
                  </td>
                  <td className="p-2.5 text-slate-200 font-semibold">{log.code}</td>
                  <td className="p-2.5 text-slate-300 font-sans">{log.details}</td>
                  <td className="p-2.5 text-slate-400">{log.operator}</td>
                  <td className="p-2.5 text-right">
                    {log.success ? (
                      <span className="text-emerald-400">PASSED</span>
                    ) : (
                      <span className="text-red-400">FAILED</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
