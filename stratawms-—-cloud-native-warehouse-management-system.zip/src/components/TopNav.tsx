import React from 'react';
import { TabMode } from '../types/wms';
import { Volume2, VolumeX, ShieldAlert, Cpu } from 'lucide-react';

interface TopNavProps {
  currentTab: TabMode;
  onTabChange: (tab: TabMode) => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  onOpenArchComparison: () => void;
  activeWavesCount: number;
  activeRobotsCount: number;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentTab,
  onTabChange,
  audioEnabled,
  onToggleAudio,
  onOpenArchComparison,
  activeWavesCount,
  activeRobotsCount,
}) => {
  return (
    <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-30 px-4 lg:px-6 py-2.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Zone 1: Brand title wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-8 h-8 rounded bg-cyan-600 flex items-center justify-center text-white font-bold text-base shadow-sm">
            S
          </div>
          <div className="flex flex-col">
            <span className="text-base font-bold tracking-tight text-white font-display">
              StrataWMS
            </span>
            <span className="text-xs text-slate-400 font-mono">
              OAK-04 East Bay Hub
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation Links (Single-line, text with clean active indicators) */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-950/70 p-1 rounded border border-slate-800">
          <button
            onClick={() => onTabChange('floor')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'floor'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            Digital Twin & Floor
          </button>

          <button
            onClick={() => onTabChange('pickpath')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              currentTab === 'pickpath'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <span>Pick-Path Optimizer</span>
            <span className="text-xs font-mono text-cyan-400 tabular-nums">
              ({activeWavesCount})
            </span>
          </button>

          <button
            onClick={() => onTabChange('scanner')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'scanner'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            Barcode & RFID Hub
          </button>

          <button
            onClick={() => onTabChange('robotics')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              currentTab === 'robotics'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <span>AMR Fleet Command</span>
            <span className="text-xs font-mono text-emerald-400 tabular-nums">
              ({activeRobotsCount})
            </span>
          </button>

          <button
            onClick={() => onTabChange('inventory')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              currentTab === 'inventory'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            Inventory Matrix & Putaway
          </button>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onToggleAudio}
            title={audioEnabled ? 'Scanner Beep: Enabled' : 'Scanner Beep: Muted'}
            className={`p-2 rounded text-xs border transition-colors flex items-center gap-1.5 ${
              audioEnabled
                ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20'
                : 'border-slate-800 bg-slate-900 text-slate-500 hover:text-slate-300'
            }`}
          >
            {audioEnabled ? <Volume2 size={15} /> : <VolumeX size={15} />}
            <span className="hidden sm:inline text-xs font-mono">Beeper</span>
          </button>

          <button
            onClick={onOpenArchComparison}
            className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors flex items-center gap-1.5 whitespace-nowrap"
          >
            <Cpu size={14} className="text-cyan-400" />
            <span className="hidden sm:inline">Cloud vs Legacy</span>
            <span className="sm:hidden">Architecture</span>
          </button>
        </div>
      </div>

      {/* Mobile Nav row */}
      <div className="flex md:hidden overflow-x-auto gap-1 mt-2 pt-2 border-t border-slate-800/80 pb-0.5 scrollbar-none">
        <button
          onClick={() => onTabChange('floor')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded font-medium ${
            currentTab === 'floor' ? 'bg-cyan-600 text-white' : 'text-slate-400'
          }`}
        >
          Twin
        </button>
        <button
          onClick={() => onTabChange('pickpath')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded font-medium ${
            currentTab === 'pickpath' ? 'bg-cyan-600 text-white' : 'text-slate-400'
          }`}
        >
          Pick-Path
        </button>
        <button
          onClick={() => onTabChange('scanner')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded font-medium ${
            currentTab === 'scanner' ? 'bg-cyan-600 text-white' : 'text-slate-400'
          }`}
        >
          Scanner & RFID
        </button>
        <button
          onClick={() => onTabChange('robotics')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded font-medium ${
            currentTab === 'robotics' ? 'bg-cyan-600 text-white' : 'text-slate-400'
          }`}
        >
          AMR Fleet
        </button>
        <button
          onClick={() => onTabChange('inventory')}
          className={`px-2.5 py-1 text-xs whitespace-nowrap rounded font-medium ${
            currentTab === 'inventory' ? 'bg-cyan-600 text-white' : 'text-slate-400'
          }`}
        >
          Inventory
        </button>
      </div>
    </header>
  );
};
