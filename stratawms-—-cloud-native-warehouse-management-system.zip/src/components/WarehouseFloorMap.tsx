import React, { useState } from 'react';
import { BinLocation, AutonomousRobot, PathAnalysis, PickItem, InventoryItem } from '../types/wms';
import { AISLE_X_COORDS, CROSS_AISLE_Y, PACKING_STATION } from '../utils/pickPathOptimizer';
import { Bot, MapPin, Zap, AlertTriangle, Layers, Navigation, Box, ArrowRight } from 'lucide-react';

interface WarehouseFloorMapProps {
  bins: BinLocation[];
  robots: AutonomousRobot[];
  activePathAnalysis: PathAnalysis | null;
  legacyPathAnalysis: PathAnalysis | null;
  showLegacyComparison: boolean;
  onToggleLegacyComparison: () => void;
  selectedBin: BinLocation | null;
  onSelectBin: (bin: BinLocation | null) => void;
  congestedAisles: number[];
  onToggleCongestion: (aisle: number) => void;
  onDispatchRobotToBin: (robotId: string, bin: BinLocation) => void;
  skus: InventoryItem[];
  onQuickPickItem?: (item: PickItem) => void;
}

export type HeatmapMode = 'NONE' | 'VELOCITY' | 'OCCUPANCY';

export const WarehouseFloorMap: React.FC<WarehouseFloorMapProps> = ({
  bins,
  robots,
  activePathAnalysis,
  legacyPathAnalysis,
  showLegacyComparison,
  onToggleLegacyComparison,
  selectedBin,
  onSelectBin,
  congestedAisles,
  onToggleCongestion,
  onDispatchRobotToBin,
  skus,
}) => {
  const [heatmapMode, setHeatmapMode] = useState<HeatmapMode>('NONE');
  const [selectedRobotId, setSelectedRobotId] = useState<string | null>(null);

  // Selected bin detail
  const selectedSku = selectedBin?.skuId ? skus.find((s) => s.id === selectedBin.skuId) : null;
  const activeRobot = selectedRobotId ? robots.find((r) => r.id === selectedRobotId) : null;

  return (
    <div className="flex flex-col lg:flex-row gap-4 h-full">
      {/* Main Floor Map Canvas container */}
      <div className="flex-1 bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col min-w-0">
        {/* Map Header Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <span className="text-sm font-semibold text-slate-200">
              Interactive Facility Twin (Grid 1000m² · OAK-04)
            </span>
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Telemetry Live</span>
            </div>
          </div>

          {/* Controls: Heatmap & Path comparison */}
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-slate-950 p-0.5 rounded border border-slate-800 text-xs">
              <span className="px-2 py-1 text-slate-400 font-mono flex items-center gap-1">
                <Layers size={13} />
                <span>Heatmap:</span>
              </span>
              <button
                onClick={() => setHeatmapMode('NONE')}
                className={`px-2 py-1 rounded transition-colors ${
                  heatmapMode === 'NONE' ? 'bg-slate-800 text-slate-200' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Off
              </button>
              <button
                onClick={() => setHeatmapMode('VELOCITY')}
                className={`px-2 py-1 rounded transition-colors ${
                  heatmapMode === 'VELOCITY' ? 'bg-cyan-500/20 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Pick Velocity
              </button>
              <button
                onClick={() => setHeatmapMode('OCCUPANCY')}
                className={`px-2 py-1 rounded transition-colors ${
                  heatmapMode === 'OCCUPANCY' ? 'bg-indigo-500/20 text-indigo-300 font-medium' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Bin Fill %
              </button>
            </div>

            <button
              onClick={onToggleLegacyComparison}
              className={`px-2.5 py-1 text-xs rounded border transition-colors flex items-center gap-1.5 ${
                showLegacyComparison
                  ? 'bg-amber-500/10 border-amber-500/40 text-amber-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-300'
              }`}
            >
              <span className="inline-block w-2 h-2 rounded-full bg-amber-400" />
              <span>Legacy S-Shape Overlay</span>
            </button>
          </div>
        </div>

        {/* Interactive SVG Warehouse Layout */}
        <div className="relative flex-1 min-h-[460px] bg-slate-950 rounded border border-slate-850 overflow-hidden flex items-center justify-center p-2">
          <svg
            viewBox="0 0 1000 600"
            className="w-full h-full select-none max-h-[580px]"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              {/* Pattern for floor grid lines */}
              <pattern id="floorGrid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="0.75" strokeOpacity="0.5" />
              </pattern>

              {/* Marker for optimized path arrows */}
              <marker id="optArrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto">
                <path d="M 0 1 L 8 5 L 0 9 z" fill="#06b6d4" />
              </marker>

              {/* Marker for legacy path arrows */}
              <marker id="legacyArrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="5" markerHeight="5" orient="auto">
                <path d="M 0 1 L 8 5 L 0 9 z" fill="#f59e0b" />
              </marker>
            </defs>

            {/* Base floor grid */}
            <rect width="1000" height="600" fill="url(#floorGrid)" />

            {/* West Inbound Docks (D1 to D4) */}
            <g id="inbound-docks">
              <rect x="15" y="40" width="80" height="460" rx="4" fill="#0f172a" stroke="#334155" strokeWidth="1.5" />
              <text x="55" y="30" fill="#94a3b8" fontSize="10" fontWeight="600" textAnchor="middle" letterSpacing="1">
                INBOUND DOCKS
              </text>
              {[1, 2, 3, 4].map((dock, idx) => (
                <g key={`dock-in-${dock}`} transform={`translate(25, ${60 + idx * 110})`}>
                  <rect width="60" height="85" rx="3" fill="#1e293b" stroke="#475569" strokeDasharray="3 2" />
                  <text x="30" y="24" fill="#38bdf8" fontSize="11" fontWeight="700" textAnchor="middle" fontFamily="JetBrains Mono">
                    DOCK 0{dock}
                  </text>
                  <rect x="10" y="36" width="40" height="36" rx="2" fill="#0284c7" fillOpacity="0.2" stroke="#0284c7" strokeWidth="0.8" />
                  <text x="30" y="58" fill="#bae6fd" fontSize="9" textAnchor="middle" fontFamily="JetBrains Mono">
                    {dock === 1 ? 'RFID GATE' : 'STAGING'}
                  </text>
                </g>
              ))}
            </g>

            {/* East Outbound Docks (D5 to D8) */}
            <g id="outbound-docks">
              <rect x="905" y="40" width="80" height="460" rx="4" fill="#0f172a" stroke="#334155" strokeWidth="1.5" />
              <text x="945" y="30" fill="#94a3b8" fontSize="10" fontWeight="600" textAnchor="middle" letterSpacing="1">
                OUTBOUND DOCKS
              </text>
              {[5, 6, 7, 8].map((dock, idx) => (
                <g key={`dock-out-${dock}`} transform={`translate(915, ${60 + idx * 110})`}>
                  <rect width="60" height="85" rx="3" fill="#1e293b" stroke="#475569" strokeDasharray="3 2" />
                  <text x="30" y="24" fill="#22c55e" fontSize="11" fontWeight="700" textAnchor="middle" fontFamily="JetBrains Mono">
                    DOCK 0{dock}
                  </text>
                  <rect x="10" y="36" width="40" height="36" rx="2" fill="#16a34a" fillOpacity="0.2" stroke="#16a34a" strokeWidth="0.8" />
                  <text x="30" y="58" fill="#bbf7d0" fontSize="9" textAnchor="middle" fontFamily="JetBrains Mono">
                    CARRIER
                  </text>
                </g>
              ))}
            </g>

            {/* Cross-Aisle Highway Lanes */}
            <g id="cross-aisles">
              {/* North Crossway */}
              <line x1="110" y1={CROSS_AISLE_Y.TOP} x2="890" y2={CROSS_AISLE_Y.TOP} stroke="#334155" strokeWidth="18" strokeLinecap="round" strokeOpacity="0.3" />
              <text x="500" y={CROSS_AISLE_Y.TOP + 4} fill="#475569" fontSize="9" fontWeight="600" textAnchor="middle" letterSpacing="1.5">
                NORTH CROSSWAY
              </text>

              {/* Middle Crossway */}
              <line x1="110" y1={CROSS_AISLE_Y.MID} x2="890" y2={CROSS_AISLE_Y.MID} stroke="#334155" strokeWidth="18" strokeLinecap="round" strokeOpacity="0.3" />
              <text x="500" y={CROSS_AISLE_Y.MID + 4} fill="#475569" fontSize="9" fontWeight="600" textAnchor="middle" letterSpacing="1.5">
                CENTRAL CROSS-CUT (TSP BYPASS)
              </text>

              {/* South Concourse */}
              <line x1="110" y1={CROSS_AISLE_Y.BOT} x2="890" y2={CROSS_AISLE_Y.BOT} stroke="#334155" strokeWidth="18" strokeLinecap="round" strokeOpacity="0.3" />
              <text x="500" y={CROSS_AISLE_Y.BOT + 4} fill="#475569" fontSize="9" fontWeight="600" textAnchor="middle" letterSpacing="1.5">
                SOUTH CONCOURSE
              </text>
            </g>

            {/* Aisle Transit Lanes & Congestion Zones */}
            {[1, 2, 3, 4, 5, 6, 7, 8].map((aisle) => {
              const x = AISLE_X_COORDS[aisle];
              const isCongested = congestedAisles.includes(aisle);

              return (
                <g key={`aisle-corridor-${aisle}`}>
                  {/* Transit line for AGVs and pickers */}
                  <line
                    x1={x}
                    y1={CROSS_AISLE_Y.TOP}
                    x2={x}
                    y2={CROSS_AISLE_Y.BOT}
                    stroke={isCongested ? '#ef4444' : '#1e293b'}
                    strokeWidth={isCongested ? '28' : '22'}
                    strokeOpacity={isCongested ? '0.35' : '0.6'}
                  />

                  {/* Aisle Header & Clickable Congestion Toggle */}
                  <g
                    className="cursor-pointer"
                    onClick={() => onToggleCongestion(aisle)}
                  >
                    <rect
                      x={x - 28}
                      y={45}
                      width="56"
                      height="20"
                      rx="3"
                      fill={isCongested ? '#7f1d1d' : '#0f172a'}
                      stroke={isCongested ? '#ef4444' : '#334155'}
                      strokeWidth="1"
                    />
                    <text
                      x={x}
                      y={59}
                      fill={isCongested ? '#fca5a5' : '#94a3b8'}
                      fontSize="9"
                      fontWeight="700"
                      textAnchor="middle"
                      fontFamily="JetBrains Mono"
                    >
                      AISLE 0{aisle}
                    </text>
                    {isCongested && (
                      <circle cx={x + 22} cy={50} r="4" fill="#ef4444" />
                    )}
                  </g>
                </g>
              );
            })}

            {/* Racks & Bins */}
            {bins.map((bin) => {
              const isSelected = selectedBin?.id === bin.id;
              const hasSku = Boolean(bin.skuId);

              // Heatmap fill logic
              let rectFill = '#1e293b';
              let strokeColor = '#334155';

              if (heatmapMode === 'VELOCITY') {
                const count = bin.pickCountToday || 0;
                if (count > 30) rectFill = '#ef4444'; // Hot pick
                else if (count > 15) rectFill = '#f97316';
                else if (count > 5) rectFill = '#06b6d4';
                else rectFill = '#1e293b';
              } else if (heatmapMode === 'OCCUPANCY') {
                const ratio = (bin.quantity || 0) / (bin.maxCapacity || 100);
                if (ratio > 0.8) rectFill = '#6366f1';
                else if (ratio > 0.4) rectFill = '#3b82f6';
                else rectFill = '#1e293b';
              } else {
                if (hasSku) {
                  rectFill = '#0f172a';
                  strokeColor = '#475569';
                }
              }

              if (isSelected) {
                strokeColor = '#38bdf8';
                rectFill = '#0284c7';
              }

              return (
                <g
                  key={bin.id}
                  className="cursor-pointer transition-all duration-150"
                  onClick={() => onSelectBin(bin)}
                >
                  <rect
                    x={bin.x - 24}
                    y={bin.y - 12}
                    width="48"
                    height="24"
                    rx="3"
                    fill={rectFill}
                    stroke={strokeColor}
                    strokeWidth={isSelected ? '2' : '1'}
                  />
                  <text
                    x={bin.x}
                    y={bin.y + 3}
                    fill={isSelected ? '#ffffff' : hasSku ? '#e2e8f0' : '#64748b'}
                    fontSize="8"
                    fontWeight="600"
                    textAnchor="middle"
                    fontFamily="JetBrains Mono"
                  >
                    {bin.id.replace('A0', 'A').replace('B0', 'B')}
                  </text>
                  {hasSku && (
                    <circle
                      cx={bin.x + 18}
                      cy={bin.y - 6}
                      r="2.5"
                      fill="#22c55e"
                    />
                  )}
                </g>
              );
            })}

            {/* Legacy S-Shape Path (Orange dashed) */}
            {showLegacyComparison && legacyPathAnalysis && legacyPathAnalysis.path.length > 1 && (
              <g id="legacy-path-overlay">
                <polyline
                  points={legacyPathAnalysis.path.map((p) => `${p.x},${p.y}`).join(' ')}
                  fill="none"
                  stroke="#f59e0b"
                  strokeWidth="2.5"
                  strokeDasharray="6 4"
                  strokeOpacity="0.85"
                  markerEnd="url(#legacyArrow)"
                />
              </g>
            )}

            {/* Modern Strata Optimized TSP Path (Cyan bold) */}
            {activePathAnalysis && activePathAnalysis.path.length > 1 && (
              <g id="optimized-path-overlay">
                <polyline
                  points={activePathAnalysis.path.map((p) => `${p.x},${p.y}`).join(' ')}
                  fill="none"
                  stroke="#06b6d4"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeOpacity="0.95"
                  markerEnd="url(#optArrow)"
                />

                {/* Sequential numbered waypoint markers */}
                {activePathAnalysis.path
                  .filter((p) => p.type === 'PICK')
                  .map((p, idx) => (
                    <g key={`opt-pick-pt-${idx}`} transform={`translate(${p.x}, ${p.y})`}>
                      <circle r="9" fill="#0891b2" stroke="#e0f2fe" strokeWidth="1.5" />
                      <text
                        y="3"
                        fill="#ffffff"
                        fontSize="9"
                        fontWeight="700"
                        textAnchor="middle"
                        fontFamily="JetBrains Mono"
                      >
                        {idx + 1}
                      </text>
                    </g>
                  ))}
              </g>
            )}

            {/* Autonomous Mobile Robots (AMRs) on floor */}
            {robots.map((robot) => {
              const isRobotSelected = selectedRobotId === robot.id;
              const hasAlert = robot.status === 'ALERT' || robot.lidarObstacleDetected;

              return (
                <g
                  key={robot.id}
                  className="cursor-pointer"
                  transform={`translate(${robot.x}, ${robot.y})`}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedRobotId(robot.id);
                  }}
                >
                  {/* LiDAR scan radius ring */}
                  <circle
                    r={hasAlert ? '22' : '16'}
                    fill={hasAlert ? '#ef4444' : '#06b6d4'}
                    fillOpacity="0.12"
                    stroke={hasAlert ? '#ef4444' : '#38bdf8'}
                    strokeWidth="0.8"
                    strokeDasharray="2 2"
                  />

                  {/* Robot chassis box */}
                  <rect
                    x="-12"
                    y="-12"
                    width="24"
                    height="24"
                    rx="4"
                    fill={isRobotSelected ? '#0284c7' : '#0f172a'}
                    stroke={hasAlert ? '#ef4444' : isRobotSelected ? '#38bdf8' : '#38bdf8'}
                    strokeWidth={isRobotSelected ? '2' : '1.2'}
                  />

                  {/* Center sensor turret */}
                  <circle cx="0" cy="0" r="4" fill={hasAlert ? '#ef4444' : '#22c55e'} />

                  {/* Robot Label */}
                  <text
                    y="22"
                    fill={isRobotSelected ? '#38bdf8' : '#cbd5e1'}
                    fontSize="8"
                    fontWeight="700"
                    textAnchor="middle"
                    fontFamily="JetBrains Mono"
                  >
                    {robot.id}
                  </text>
                </g>
              );
            })}

            {/* Central Packing Line (Origin / Destination) */}
            <g transform={`translate(${PACKING_STATION.x - 90}, ${PACKING_STATION.y - 25})`}>
              <rect
                width="180"
                height="50"
                rx="5"
                fill="#0f172a"
                stroke="#0284c7"
                strokeWidth="1.5"
              />
              <text x="90" y="20" fill="#38bdf8" fontSize="10" fontWeight="700" textAnchor="middle" letterSpacing="0.5">
                PACKING STATION CENTRAL
              </text>
              <text x="90" y="38" fill="#94a3b8" fontSize="8" textAnchor="middle" fontFamily="JetBrains Mono">
                WAVE DISPATCH & CONSOLIDATION
              </text>
              <circle cx="20" cy="25" r="4" fill="#22c55e" />
              <circle cx="160" cy="25" r="4" fill="#22c55e" />
            </g>

            {/* AMR Fast Charging Pad (Bottom Right) */}
            <g transform="translate(860, 520)">
              <rect width="110" height="45" rx="4" fill="#0f172a" stroke="#ca8a04" strokeWidth="1.2" strokeDasharray="3 2" />
              <text x="55" y="20" fill="#fde047" fontSize="9" fontWeight="700" textAnchor="middle" letterSpacing="0.5">
                AMR INDUCTIVE CHARGE
              </text>
              <text x="55" y="36" fill="#ca8a04" fontSize="8" textAnchor="middle" fontFamily="JetBrains Mono">
                BAY 01 · 45kW DOCK
              </text>
            </g>
          </svg>
        </div>

        {/* Floor Map Legend Footer */}
        <div className="flex flex-wrap items-center justify-between text-xs text-slate-400 mt-2.5 pt-2 border-t border-slate-800">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-cyan-400 inline-block" />
              <span>Strata Optimized TSP Route</span>
            </div>
            {showLegacyComparison && (
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-amber-400 border-t border-dashed inline-block" />
                <span>Legacy S-Shape Traversal</span>
              </div>
            )}
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-slate-900 border border-slate-700 inline-block" />
              <span>Rack Bins</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 inline-block" />
              <span>Active AMR</span>
            </div>
          </div>

          <div className="text-slate-400 font-mono text-xs">
            Tip: Click Aisle header to simulate forklift blockage & dynamic rerouting.
          </div>
        </div>
      </div>

      {/* Right Contextual Inspection Panel */}
      <div className="w-full lg:w-80 flex flex-col gap-4">
        {/* Bin Location Details Inspector */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
            <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <MapPin size={14} className="text-cyan-400" />
              <span>Bin Location Inspector</span>
            </span>
            {selectedBin && (
              <span className="text-xs font-mono text-cyan-400">
                {selectedBin.id}
              </span>
            )}
          </div>

          {selectedBin ? (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-slate-950 p-2 rounded border border-slate-850">
                  <span className="text-slate-500 block">Aisle / Bay / Level</span>
                  <span className="font-mono text-slate-200 font-semibold">
                    A{selectedBin.aisle} · B0{selectedBin.bay} · L{selectedBin.level}
                  </span>
                </div>
                <div className="bg-slate-950 p-2 rounded border border-slate-850">
                  <span className="text-slate-500 block">Pick Velocity</span>
                  <span className="font-mono text-slate-200 font-semibold">
                    {selectedBin.pickCountToday || 0} picks/day
                  </span>
                </div>
              </div>

              {selectedSku ? (
                <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-cyan-400 font-semibold">{selectedSku.id}</span>
                    <span className="text-xs text-slate-400 font-mono">Class {selectedSku.velocityClass}</span>
                  </div>
                  <div className="text-xs text-slate-200 font-medium leading-snug">
                    {selectedSku.name}
                  </div>
                  <div className="grid grid-cols-3 gap-1 pt-1 text-xs font-mono border-t border-slate-850">
                    <div>
                      <span className="text-slate-500 block text-xs">On-Hand</span>
                      <span className="text-slate-200 tabular-nums">{selectedSku.onHand}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-xs">Alloc</span>
                      <span className="text-amber-400 tabular-nums">{selectedSku.allocated}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-xs">Avail</span>
                      <span className="text-emerald-400 tabular-nums">{selectedSku.available}</span>
                    </div>
                  </div>
                  <div className="text-xs text-slate-500 font-mono pt-1">
                    RFID EPC: <span className="text-slate-300">{selectedSku.rfidEpc.slice(-8)}</span>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-slate-500 bg-slate-950 p-3 rounded border border-slate-800 text-center">
                  Bin currently unassigned or empty buffer.
                </div>
              )}

              {/* Action buttons */}
              <div className="space-y-1.5 pt-1">
                <button
                  onClick={() => onDispatchRobotToBin('AMR-102', selectedBin)}
                  className="w-full py-1.5 px-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-xs font-medium transition-colors flex items-center justify-center gap-1.5"
                >
                  <Bot size={13} />
                  <span>Dispatch AMR-102 to Bin</span>
                </button>
                <button
                  onClick={() => onToggleCongestion(selectedBin.aisle)}
                  className="w-full py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs font-medium transition-colors flex items-center justify-center gap-1.5"
                >
                  <AlertTriangle size={13} className={congestedAisles.includes(selectedBin.aisle) ? 'text-red-400' : 'text-slate-400'} />
                  <span>
                    {congestedAisles.includes(selectedBin.aisle) ? 'Clear Aisle Blockage' : 'Simulate Aisle Blockage'}
                  </span>
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-slate-500 text-xs">
              <Box size={24} className="mx-auto mb-2 opacity-50" />
              Click any rack bay on the floor map to inspect stored SKUs, occupancy, and dispatch AMRs.
            </div>
          )}
        </div>

        {/* AMR Fleet Telemetry Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex-1">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
            <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Bot size={14} className="text-emerald-400" />
              <span>Robot Fleet Status</span>
            </span>
            <span className="text-xs text-slate-400 font-mono tabular-nums">
              {robots.length} Units Active
            </span>
          </div>

          <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
            {robots.map((robot) => {
              const isSelected = selectedRobotId === robot.id;
              return (
                <div
                  key={robot.id}
                  onClick={() => setSelectedRobotId(robot.id)}
                  className={`p-2.5 rounded border text-xs cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-slate-850 border-cyan-500/50'
                      : 'bg-slate-950 border-slate-850 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-slate-200 font-mono">{robot.id} ({robot.name})</span>
                    <span className="font-mono text-emerald-400 tabular-nums">{robot.batteryPercent}%</span>
                  </div>
                  <div className="text-xs text-slate-400 truncate">
                    {robot.currentMission || 'Standing by'}
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mt-1 font-mono">
                    <span>{robot.status}</span>
                    <span>{robot.velocityMps} m/s · {robot.payloadKg}kg</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
