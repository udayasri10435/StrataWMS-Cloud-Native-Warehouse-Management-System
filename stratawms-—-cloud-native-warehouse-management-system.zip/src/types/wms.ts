export type TabMode = 'floor' | 'pickpath' | 'scanner' | 'robotics' | 'inventory';

export type VelocityClass = 'A' | 'B' | 'C'; // A = High velocity, B = Medium, C = Slow/bulky

export interface BinLocation {
  id: string; // e.g. "A03-B04-L2"
  aisle: number; // 1 to 8
  bay: number; // 1 to 8
  level: number; // 1 to 5
  x: number; // SVG coordinate
  y: number; // SVG coordinate
  zone: 'RACK' | 'DOCK_IN' | 'DOCK_OUT' | 'PACKING' | 'CHARGING' | 'STAGING';
  skuId?: string;
  quantity?: number;
  maxCapacity?: number;
  pickCountToday?: number;
}

export interface InventoryItem {
  id: string; // SKU
  name: string;
  category: string;
  barcode: string; // Code-128 / GS1-128
  rfidEpc: string; // EPC Gen2 24-char hex
  binId: string;
  onHand: number;
  allocated: number;
  available: number;
  reorderPoint: number;
  unitWeightKg: number;
  velocityClass: VelocityClass;
  lastScannedAt?: string;
}

export interface PickItem {
  id: string;
  skuId: string;
  name: string;
  barcode: string;
  binId: string;
  quantity: number;
  picked: boolean;
  x: number;
  y: number;
  aisle: number;
  bay: number;
}

export interface PickWave {
  id: string;
  orderNumber: string;
  customer: string;
  priority: 'CRITICAL' | 'HIGH' | 'STANDARD';
  assignedPicker: string;
  assignedAmrId?: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED';
  items: PickItem[];
  createdAt: string;
}

export interface PickPathPoint {
  x: number;
  y: number;
  type: 'START' | 'TRANSIT' | 'PICK' | 'END';
  binId?: string;
  itemDescription?: string;
  instruction?: string;
}

export interface PathAnalysis {
  strategy: 'LEGACY_S_SHAPE' | 'OPTIMIZED_TSP';
  path: PickPathPoint[];
  totalDistanceMeters: number;
  estimatedTimeSeconds: number;
  turnCount: number;
  congestionPenaltySeconds: number;
  savingPercent?: number;
}

export type AmrStatus = 'NAVIGATING' | 'PICKING' | 'DOCKING' | 'CHARGING' | 'IDLE' | 'ALERT';

export interface AutonomousRobot {
  id: string;
  name: string;
  type: 'SHELF_CARRIER' | 'PALLET_AMR' | 'TUGGER_TRAIN';
  batteryPercent: number;
  status: AmrStatus;
  x: number;
  y: number;
  targetX?: number;
  targetY?: number;
  targetWaypoint?: string;
  velocityMps: number;
  payloadKg: number;
  maxPayloadKg: number;
  currentMission?: string;
  lidarObstacleDetected: boolean;
  assignedOrderWaveId?: string;
}

export interface RFIDTagRead {
  epc: string;
  sku: string;
  description: string;
  antennaId: number;
  rssiDb: number; // e.g. -42 to -78 dBm
  timestamp: string;
  status: 'MATCHED' | 'UNEXPECTED' | 'DISCREPANCY';
}

export interface AsnManifestItem {
  sku: string;
  expectedQty: number;
  scannedQty: number;
  description: string;
}

export interface ScanLogEntry {
  id: string;
  type: 'BARCODE' | 'RFID' | 'PUTAWAY' | 'PICK';
  code: string;
  details: string;
  success: boolean;
  timestamp: string;
  operator: string;
}
