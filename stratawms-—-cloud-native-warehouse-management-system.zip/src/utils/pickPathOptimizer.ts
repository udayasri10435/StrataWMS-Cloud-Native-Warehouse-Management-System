import { PickItem, PickPathPoint, PathAnalysis } from '../types/wms';

// Warehouse grid coordinates (normalized for a 1000 x 600 warehouse map)
// Packing stations (origin / start & end of pick paths):
export const PACKING_STATION = { x: 500, y: 550, name: 'Packing Station Central' };
export const INBOUND_DOCK = { x: 80, y: 100, name: 'Inbound Dock Bay 01' };

// Aisle geometry:
// 8 Aisles: Aisle 1 (x: 180), Aisle 2 (x: 270), Aisle 3 (x: 360), Aisle 4 (x: 450),
//           Aisle 5 (x: 550), Aisle 6 (x: 640), Aisle 7 (x: 730), Aisle 8 (x: 820)
// Cross-aisles:
// Top cross-aisle: y = 80
// Middle cross-aisle: y = 280
// Bottom cross-aisle: y = 480
export const AISLE_X_COORDS: Record<number, number> = {
  1: 180,
  2: 270,
  3: 360,
  4: 450,
  5: 550,
  6: 640,
  7: 730,
  8: 820,
};

export const CROSS_AISLE_Y = {
  TOP: 80,
  MID: 280,
  BOT: 480,
};

// Euclidean distance in SVG units
function distance(p1: { x: number; y: number }, p2: { x: number; y: number }): number {
  return Math.hypot(p1.x - p2.x, p1.y - p2.y);
}

// Convert SVG pixels to estimated warehouse meters (scale: 1 unit ~ 0.2 meters)
export function pixelsToMeters(px: number): number {
  return Math.round(px * 0.22);
}

/**
 * Calculates a route using the Legacy S-Shape (traversal) heuristic.
 * Visits aisles left to right. Traverses entire aisles if any item is picked.
 */
export function calculateLegacySShape(items: PickItem[], congestedAisles: number[] = []): PathAnalysis {
  if (items.length === 0) {
    return {
      strategy: 'LEGACY_S_SHAPE',
      path: [],
      totalDistanceMeters: 0,
      estimatedTimeSeconds: 0,
      turnCount: 0,
      congestionPenaltySeconds: 0,
    };
  }

  const path: PickPathPoint[] = [];
  path.push({
    x: PACKING_STATION.x,
    y: PACKING_STATION.y,
    type: 'START',
    instruction: 'Depart Packing Line 01',
  });

  // Group items by aisle
  const aisleMap = new Map<number, PickItem[]>();
  for (const item of items) {
    const list = aisleMap.get(item.aisle) || [];
    list.push(item);
    aisleMap.set(item.aisle, list);
  }

  const sortedAisles = Array.from(aisleMap.keys()).sort((a, b) => a - b);
  let currentYDirection: 'DOWN' | 'UP' = 'DOWN'; // alternating direction
  let totalPixelDistance = 0;
  let turns = 0;
  let congestionPenalty = 0;

  // Initial move to bottom of first aisle
  const firstAisle = sortedAisles[0];
  const firstAisleX = AISLE_X_COORDS[firstAisle] || 200;
  
  // Navigate via bottom cross aisle to first aisle
  path.push({
    x: firstAisleX,
    y: CROSS_AISLE_Y.BOT,
    type: 'TRANSIT',
    instruction: `Transit to Aisle ${firstAisle} South Entry`,
  });
  turns += 2;

  let currentPos = { x: firstAisleX, y: CROSS_AISLE_Y.BOT };

  sortedAisles.forEach((aisleNum, idx) => {
    const aisleX = AISLE_X_COORDS[aisleNum] || 200;
    const aisleItems = aisleMap.get(aisleNum) || [];

    if (congestedAisles.includes(aisleNum)) {
      congestionPenalty += 35; // seconds delay due to forklift congestion
    }

    // Sort items along current traversal direction
    const sortedItems = [...aisleItems].sort((a, b) => {
      return currentYDirection === 'DOWN' ? a.y - b.y : b.y - a.y;
    });

    // In legacy S-Shape, travel across bottom/top cross-aisle to this aisle
    if (idx > 0) {
      const crossY = currentYDirection === 'DOWN' ? CROSS_AISLE_Y.BOT : CROSS_AISLE_Y.TOP;
      path.push({
        x: aisleX,
        y: crossY,
        type: 'TRANSIT',
        instruction: `Cross to Aisle ${aisleNum}`,
      });
      turns += 2;
      totalPixelDistance += distance(currentPos, { x: aisleX, y: crossY });
      currentPos = { x: aisleX, y: crossY };
    }

    // Pick each item in order
    sortedItems.forEach((item) => {
      path.push({
        x: item.x,
        y: item.y,
        type: 'PICK',
        binId: item.binId,
        itemDescription: `${item.name} (${item.quantity}x)`,
        instruction: `Pick SKU ${item.skuId} at Bin ${item.binId}`,
      });
      totalPixelDistance += distance(currentPos, { x: item.x, y: item.y });
      currentPos = { x: item.x, y: item.y };
    });

    // Legacy S-Shape goes all the way to the other end of the aisle!
    const targetEndCrossY = currentYDirection === 'DOWN' ? CROSS_AISLE_Y.TOP : CROSS_AISLE_Y.BOT;
    path.push({
      x: aisleX,
      y: targetEndCrossY,
      type: 'TRANSIT',
      instruction: `Complete full traversal of Aisle ${aisleNum}`,
    });
    totalPixelDistance += distance(currentPos, { x: aisleX, y: targetEndCrossY });
    currentPos = { x: aisleX, y: targetEndCrossY };
    turns += 1;

    // Flip direction for next aisle
    currentYDirection = currentYDirection === 'DOWN' ? 'UP' : 'DOWN';
  });

  // Return to packing station
  path.push({
    x: PACKING_STATION.x,
    y: currentPos.y,
    type: 'TRANSIT',
    instruction: 'Transit to Central Concourse',
  });
  path.push({
    x: PACKING_STATION.x,
    y: PACKING_STATION.y,
    type: 'END',
    instruction: 'Drop batch at Packing Station Central',
  });
  turns += 2;
  totalPixelDistance += distance(currentPos, { x: PACKING_STATION.x, y: PACKING_STATION.y });

  const totalDistanceMeters = pixelsToMeters(totalPixelDistance);
  // Average picking speed: 1.1 m/s + 8s per pick + turn delay (2.5s per turn)
  const walkingTimeSeconds = Math.round(totalDistanceMeters / 1.1);
  const pickingTimeSeconds = items.length * 9;
  const turnTimeSeconds = turns * 2.5;
  const estimatedTimeSeconds = Math.round(walkingTimeSeconds + pickingTimeSeconds + turnTimeSeconds + congestionPenalty);

  return {
    strategy: 'LEGACY_S_SHAPE',
    path,
    totalDistanceMeters,
    estimatedTimeSeconds,
    turnCount: turns,
    congestionPenaltySeconds: congestionPenalty,
  };
}

/**
 * Modern Strata Dynamic Algorithmic Optimizer:
 * Uses dynamic programming / 2-opt TSP with middle cross-aisle shortcuts,
 * minimum distance routing, and congestion rerouting.
 */
export function calculateOptimizedPath(items: PickItem[], congestedAisles: number[] = []): PathAnalysis {
  if (items.length === 0) {
    return {
      strategy: 'OPTIMIZED_TSP',
      path: [],
      totalDistanceMeters: 0,
      estimatedTimeSeconds: 0,
      turnCount: 0,
      congestionPenaltySeconds: 0,
    };
  }

  // Find nearest neighbor sequence starting from Packing Station
  const remaining = [...items];
  const orderedPicks: PickItem[] = [];
  let currentCoord = { x: PACKING_STATION.x, y: PACKING_STATION.y };

  while (remaining.length > 0) {
    let bestIdx = 0;
    let bestDist = Infinity;

    for (let i = 0; i < remaining.length; i++) {
      const item = remaining[i];
      let d = distance(currentCoord, { x: item.x, y: item.y });
      // Apply congestion penalty factor if aisle is blocked
      if (congestedAisles.includes(item.aisle)) {
        d *= 1.35;
      }
      if (d < bestDist) {
        bestDist = d;
        bestIdx = i;
      }
    }

    const nextItem = remaining.splice(bestIdx, 1)[0];
    orderedPicks.push(nextItem);
    currentCoord = { x: nextItem.x, y: nextItem.y };
  }

  // 2-Opt local search refinement for shortest loop
  if (orderedPicks.length >= 4) {
    let improved = true;
    let iterations = 0;
    while (improved && iterations < 30) {
      improved = false;
      iterations++;
      for (let i = 0; i < orderedPicks.length - 1; i++) {
        for (let k = i + 1; k < orderedPicks.length; k++) {
          const currentPairDist =
            distance(i === 0 ? PACKING_STATION : orderedPicks[i - 1], orderedPicks[i]) +
            distance(orderedPicks[k], k === orderedPicks.length - 1 ? PACKING_STATION : orderedPicks[k + 1]);

          const reversedPairDist =
            distance(i === 0 ? PACKING_STATION : orderedPicks[i - 1], orderedPicks[k]) +
            distance(orderedPicks[i], k === orderedPicks.length - 1 ? PACKING_STATION : orderedPicks[k + 1]);

          if (reversedPairDist < currentPairDist) {
            // Reverse sub-array between i and k
            const sub = orderedPicks.slice(i, k + 1).reverse();
            orderedPicks.splice(i, k - i + 1, ...sub);
            improved = true;
          }
        }
      }
    }
  }

  // Construct realistic navigable waypoint path using cross-aisles
  const path: PickPathPoint[] = [];
  path.push({
    x: PACKING_STATION.x,
    y: PACKING_STATION.y,
    type: 'START',
    instruction: 'Depart Packing Station (Optimized Wave)',
  });

  let prevPos = { x: PACKING_STATION.x, y: PACKING_STATION.y };
  let totalPixelDistance = 0;
  let turns = 0;
  let congestionPenalty = 0;

  for (let i = 0; i < orderedPicks.length; i++) {
    const item = orderedPicks[i];
    const prevAisle = i === 0 ? null : orderedPicks[i - 1].aisle;

    if (congestedAisles.includes(item.aisle)) {
      congestionPenalty += 8; // smart reroute minimizes waiting compared to legacy 35s
    }

    // If moving between different aisles, route via nearest cross-aisle (Top, Mid, or Bot)
    if (prevAisle !== null && prevAisle !== item.aisle) {
      // Pick best cross-aisle: Top (80), Mid (280), or Bot (480)
      const avgY = (prevPos.y + item.y) / 2;
      let crossY = CROSS_AISLE_Y.MID;
      if (avgY < 180) crossY = CROSS_AISLE_Y.TOP;
      else if (avgY > 380) crossY = CROSS_AISLE_Y.BOT;

      // Waypoint 1: exit previous aisle at crossY
      path.push({
        x: prevPos.x,
        y: crossY,
        type: 'TRANSIT',
        instruction: `Transit to cross-cut (y=${crossY})`,
      });
      totalPixelDistance += distance(prevPos, { x: prevPos.x, y: crossY });
      turns += 1;

      // Waypoint 2: cross to new aisle at crossY
      path.push({
        x: item.x,
        y: crossY,
        type: 'TRANSIT',
        instruction: `Transfer to Aisle ${item.aisle}`,
      });
      totalPixelDistance += distance({ x: prevPos.x, y: crossY }, { x: item.x, y: crossY });
      turns += 1;

      prevPos = { x: item.x, y: crossY };
    }

    // Reach pick location
    path.push({
      x: item.x,
      y: item.y,
      type: 'PICK',
      binId: item.binId,
      itemDescription: `${item.name} (${item.quantity}x)`,
      instruction: `Pick SKU ${item.skuId} at Bin ${item.binId}`,
    });
    totalPixelDistance += distance(prevPos, { x: item.x, y: item.y });
    prevPos = { x: item.x, y: item.y };
  }

  // Return to packing station via nearest bottom concourse
  path.push({
    x: prevPos.x,
    y: CROSS_AISLE_Y.BOT,
    type: 'TRANSIT',
    instruction: 'Exit to South Concourse',
  });
  totalPixelDistance += distance(prevPos, { x: prevPos.x, y: CROSS_AISLE_Y.BOT });
  turns += 1;

  path.push({
    x: PACKING_STATION.x,
    y: CROSS_AISLE_Y.BOT,
    type: 'TRANSIT',
    instruction: 'Direct vector to Packing Station',
  });
  totalPixelDistance += distance({ x: prevPos.x, y: CROSS_AISLE_Y.BOT }, { x: PACKING_STATION.x, y: CROSS_AISLE_Y.BOT });
  turns += 1;

  path.push({
    x: PACKING_STATION.x,
    y: PACKING_STATION.y,
    type: 'END',
    instruction: 'Complete wave at Packing Station',
  });
  totalPixelDistance += distance({ x: PACKING_STATION.x, y: CROSS_AISLE_Y.BOT }, PACKING_STATION);

  const totalDistanceMeters = pixelsToMeters(totalPixelDistance);
  const walkingTimeSeconds = Math.round(totalDistanceMeters / 1.15); // Faster transit due to straight runs
  const pickingTimeSeconds = items.length * 9;
  const turnTimeSeconds = turns * 2.0;
  const estimatedTimeSeconds = Math.round(walkingTimeSeconds + pickingTimeSeconds + turnTimeSeconds + congestionPenalty);

  return {
    strategy: 'OPTIMIZED_TSP',
    path,
    totalDistanceMeters,
    estimatedTimeSeconds,
    turnCount: turns,
    congestionPenaltySeconds: congestionPenalty,
  };
}
